<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Employee;
use App\Models\Role;
use App\Models\User;
use App\Services\MailService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class EmployeeController extends Controller
{
    /** GET /api/employees — tenant-scoped, filterable by team/department/branch/status. */
    public function index(Request $request): JsonResponse
    {
        $employees = Employee::query()
            ->with(['team:id,name', 'department:id,name', 'branch:id,name', 'designation:id,name', 'shift:id,name'])
            ->when($request->team_id, fn ($q, $v) => $q->where('team_id', $v))
            ->when($request->department_id, fn ($q, $v) => $q->where('department_id', $v))
            ->when($request->branch_id, fn ($q, $v) => $q->where('branch_id', $v))
            ->when($request->status, fn ($q, $v) => $q->where('employment_status', $v))
            ->when($request->q, fn ($q, $v) => $q->where(fn ($w) =>
                $w->where('first_name', 'like', "%{$v}%")
                  ->orWhere('last_name', 'like', "%{$v}%")
                  ->orWhere('employee_code', 'like', "%{$v}%")))
            ->latest('id')
            ->paginate((int) $request->integer('per_page', 25));

        return response()->json($employees);
    }

    /** GET /api/employees/{employee} */
    public function show(Employee $employee): JsonResponse
    {
        return response()->json(['data' => $employee->load([
            'team', 'department', 'branch', 'designation', 'shift', 'devices', 'manager:id,name',
        ])]);
    }

    /** POST /api/employees */
    public function store(Request $request): JsonResponse
    {
        $data = $this->validated($request, true);
        $employee = Employee::create($data); // company_id auto-filled
        $this->audit($request, 'CREATE', Employee::class, $employee->id, $data);

        $response = ['data' => $employee];

        // Release-1: every new employee gets a self-service EMPLOYEE login by
        // default (opt out with create_login=false, or by linking user_id
        // explicitly). Skipped when there is no email to sign in with, or the
        // email already belongs to a login — we never fail the employee create
        // over the optional account.
        if ($request->boolean('create_login', true)
            && empty($data['user_id'])
            && ! empty($employee->email)
            && ! User::where('email', $employee->email)->exists()) {
            // Temp password is returned exactly once — only the hash is stored.
            $temp = Str::password(10);

            $login = User::create([
                'name'                 => $employee->fullName(),
                'email'                => $employee->email,
                'password'             => $temp, // hashed by the model cast
                'company_id'           => $employee->company_id,
                'branch_id'            => $employee->branch_id,
                'role_id'              => Role::where('slug', 'EMPLOYEE')->whereNull('company_id')->value('id'),
                'status'               => 'ACTIVE',
                'must_change_password' => true,
            ]);

            $employee->update(['user_id' => $login->id]);
            MailService::sendCredentials($login, $temp); // best-effort, never blocks
            $this->audit($request, 'CREATE', User::class, $login->id, [
                'email' => $login->email, 'role' => 'EMPLOYEE', 'employee_id' => $employee->id,
            ]);

            $response['login'] = ['user_id' => $login->id, 'email' => $login->email];
            $response['temp_password'] = $temp;
        }

        return response()->json($response, 201);
    }

    /** PUT /api/employees/{employee} */
    public function update(Request $request, Employee $employee): JsonResponse
    {
        $data = $this->validated($request, false, $employee);
        $employee->update($data);
        $this->audit($request, 'UPDATE', Employee::class, $employee->id, $data);

        return response()->json(['data' => $employee]);
    }

    /** DELETE /api/employees/{employee} */
    public function destroy(Request $request, Employee $employee): JsonResponse
    {
        $employee->delete();
        $this->audit($request, 'DELETE', Employee::class, $employee->id);

        return response()->json(null, 204);
    }

    private function validated(Request $request, bool $creating, ?Employee $employee = null): array
    {
        $req = $creating ? 'required' : 'sometimes';

        // employee_code is unique per company (DB has a composite unique index) —
        // validate it here so a duplicate returns 422 instead of a 500 from the DB.
        $companyId = $request->user()->company_id ?? $employee?->company_id;

        return $request->validate([
            'employee_code'        => [
                $req, 'string', 'max:64',
                Rule::unique('employees', 'employee_code')
                    ->where(fn ($q) => $q->where('company_id', $companyId))
                    ->ignore($employee?->id),
            ],
            'first_name'           => [$req, 'string', 'max:255'],
            'last_name'            => ['nullable', 'string', 'max:255'],
            'email'                => ['nullable', 'email'],
            'mobile'               => ['nullable', 'string', 'max:32'],
            'branch_id'            => ['nullable', 'integer', 'exists:branches,id'],
            'department_id'        => ['nullable', 'integer', 'exists:departments,id'],
            'team_id'              => ['nullable', 'integer', 'exists:teams,id'],
            'designation_id'       => ['nullable', 'integer', 'exists:designations,id'],
            'shift_id'             => ['nullable', 'integer', 'exists:shifts,id'],
            'manager_user_id'      => ['nullable', 'integer', 'exists:users,id'],
            'user_id'              => ['nullable', 'integer', 'exists:users,id'],
            'employment_status'    => ['nullable', 'in:ACTIVE,ON_LEAVE,RELIEVED'],
            'date_of_joining'      => ['nullable', 'date'],
            'biometric_id'         => ['nullable', 'string', 'max:64'],
            'smartprs_employee_id' => ['nullable', 'string', 'max:64'],
            'smartdcm_user_id'     => ['nullable', 'string', 'max:64'],
            'monitoring_policy_id' => ['nullable', 'integer'],
            'compliance_policy_id' => ['nullable', 'integer'],
        ]);
    }
}
