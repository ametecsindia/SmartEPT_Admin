<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SmartEPT — Admin Console</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">
<style>
  /* ============================================================
     SmartEPT Admin Console — Design System v2 (Ocean Teal)
     17-Jul-2026 visual upgrade: SAME classes, SAME behaviour —
     only the design layer changed. Matches Central + Client Portal.
     ============================================================ */
  :root{
    --canvas:#EEF3F6;--card:#FFFFFF;--card-2:#F7FAFB;--border:#E3E9EF;--hairline:#EEF2F6;
    --ink:#0F1E26;--ink-2:#4A5A66;--ink-3:#8494A0;
    --accent:#0E7C8F;--accent-2:#22B8CF;--accent-3:#31D2E8;--accent-weak:#E1F3F6;--accent-ink:#0A6273;
    --ok:#0A9464;--ok-w:#E3F6EE;--warn:#B7791F;--warn-w:#FBF3E2;--danger:#D22A4C;--danger-w:#FBE9ED;
    --info:#0B72C9;--info-w:#E6F1FB;--idle:#6D28D9;--idle-w:#F0EAFC;
    --navy:#052A33;--navy-2:#0B4A56;
    --font-head:'Plus Jakarta Sans','Inter','Segoe UI',sans-serif;
    --shadow-1:0 1px 2px rgba(15,30,38,.05),0 4px 14px rgba(15,30,38,.05);
    --shadow-2:0 4px 10px rgba(15,30,38,.07),0 14px 34px rgba(15,30,38,.09);
    --ring:0 0 0 3px rgba(34,184,207,.22);
  }
  *{box-sizing:border-box;margin:0;padding:0}
  html{scrollbar-color:#C6D2DA transparent;scrollbar-width:thin}
  body{font-family:'Inter','Segoe UI',system-ui,Arial,sans-serif;background:
    radial-gradient(900px 300px at 85% -80px, rgba(34,184,207,.10), transparent 60%),
    var(--canvas);color:var(--ink);font-size:13.5px;-webkit-font-smoothing:antialiased}
  ::selection{background:rgba(34,184,207,.25)}
  ::-webkit-scrollbar{width:9px;height:9px}
  ::-webkit-scrollbar-thumb{background:#C6D2DA;border-radius:8px;border:2px solid var(--canvas)}
  ::-webkit-scrollbar-thumb:hover{background:#AEBEC9}
  .hide{display:none!important}
  a{color:var(--accent);text-decoration:none}
  a:hover{color:var(--accent-ink)}
  h1,h2,h3,h4{font-family:var(--font-head);letter-spacing:-.01em}

  /* ---------- Login ---------- */
  .login{min-height:100vh;display:flex;align-items:center;justify-content:center;
    background:linear-gradient(150deg,var(--navy) 0%,#083A44 55%,var(--navy-2) 100%);position:relative;overflow:hidden}
  .login::before{content:'';position:absolute;width:640px;height:640px;border-radius:50%;
    background:radial-gradient(circle,rgba(34,184,207,.20),transparent 65%);top:-260px;right:-160px}
  .login::after{content:'';position:absolute;width:520px;height:520px;border-radius:50%;
    background:radial-gradient(circle,rgba(14,124,143,.25),transparent 65%);bottom:-240px;left:-140px}
  .login .box{background:var(--card);border:none;border-radius:20px;padding:34px 32px;width:384px;
    box-shadow:0 30px 90px rgba(0,0,0,.45);position:relative;z-index:2}
  .login .box::before{content:'';display:block;position:absolute;top:0;left:24px;right:24px;height:4px;
    border-radius:0 0 6px 6px;background:linear-gradient(90deg,var(--accent),var(--accent-3))}
  .lock{display:flex;align-items:center;gap:11px;margin-bottom:22px}
  .mark{width:42px;height:42px;border-radius:12px;background:linear-gradient(135deg,var(--accent),var(--accent-2));
    display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:13px;flex:none;
    box-shadow:0 6px 16px rgba(14,124,143,.35);font-family:var(--font-head)}
  .lock h1{font-size:19px;font-weight:800}
  .lock small{display:block;color:var(--ink-3);font-size:9px;font-weight:700;letter-spacing:2px}
  label{display:block;font-size:11px;color:var(--ink-2);font-weight:700;margin:13px 0 5px}
  input,select,textarea{width:100%;background:var(--card-2);border:1.5px solid var(--border);border-radius:10px;
    padding:10px 12px;font-size:13px;font-family:inherit;color:var(--ink);transition:border-color .15s, box-shadow .15s}
  input:focus,select:focus,textarea:focus{outline:none;border-color:var(--accent-2);box-shadow:var(--ring);background:#fff}
  input[type=checkbox]{width:auto;accent-color:var(--accent);transform:scale(1.15);cursor:pointer;box-shadow:none}
  button.primary{width:100%;margin-top:20px;background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;
    border:none;border-radius:10px;padding:12px;font-weight:700;font-size:13.5px;cursor:pointer;font-family:inherit;
    box-shadow:0 8px 20px rgba(14,124,143,.35);transition:transform .12s, box-shadow .12s}
  button.primary:hover{transform:translateY(-1px);box-shadow:0 12px 26px rgba(14,124,143,.45)}
  .err{color:var(--danger);font-size:12px;margin-top:12px;min-height:15px}

  /* ---------- Shell ---------- */
  .shell{display:flex;min-height:100vh}
  .side{width:232px;background:linear-gradient(178deg,var(--navy) 0%,#07333D 60%,#083A44 100%);
    border-right:none;position:fixed;height:100vh;padding:18px 13px 14px;display:flex;flex-direction:column;gap:2px;
    overflow-y:auto;z-index:6;scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.18) transparent}
  .side::-webkit-scrollbar{width:5px}
  .side::-webkit-scrollbar-thumb{background:rgba(255,255,255,.16);border:none}
  .side .lock{padding:4px 8px 16px;margin:0;border-bottom:1px solid rgba(255,255,255,.09)}
  .side .lock h1{color:#fff}
  .side .lock small{color:#7FA8AF}
  .navgrp{font-size:9.5px;letter-spacing:2.2px;color:#5E858C;font-weight:800;margin:16px 12px 6px;font-family:var(--font-head)}
  .nav{display:flex;align-items:center;gap:11px;padding:9.5px 12px;border-radius:10px;color:#A9CBD1;font-size:13.5px;
    font-weight:600;letter-spacing:.1px;cursor:pointer;transition:background .12s,color .12s}
  .nav:hover{background:rgba(255,255,255,.07);color:#fff}
  .nav.active{background:linear-gradient(135deg,var(--accent),#1899AE);color:#fff;box-shadow:0 4px 12px rgba(0,0,0,.25)}
  .nav .ic{width:18px;height:18px;display:flex;align-items:center;justify-content:center;opacity:.9;flex:none}
  .nav .ic svg{width:16.5px;height:16.5px;display:block}
  .nav.active .ic{opacity:1}
  .side .foot{margin-top:auto;font-size:11px;color:#7FA8AF;padding:12px 8px 2px;border-top:1px solid rgba(255,255,255,.09);line-height:1.7}
  .side .foot a{color:#A9CBD1!important}
  .side .foot a:hover{color:#fff!important}
  .main{margin-left:232px;flex:1;padding:0 28px 44px;min-width:0}
  .top{display:flex;align-items:center;justify-content:space-between;padding:18px 0 14px;position:sticky;top:0;
    background:linear-gradient(to bottom, var(--canvas) 82%, rgba(238,243,246,0));border-bottom:1px solid var(--border);
    margin-bottom:22px;z-index:5;backdrop-filter:blur(3px)}
  .top h2{font-size:21px;font-weight:800}
  .top .sub{color:var(--ink-3);font-size:12px;margin-top:2px}
  .who{font-size:12px;color:var(--ink-2);display:flex;align-items:center;gap:12px}
  .who b{color:var(--ink)}
  .help-i{width:28px;height:28px;border-radius:50%;border:1.5px solid var(--accent);color:var(--accent);
    background:var(--accent-weak);font-weight:800;font-size:13px;cursor:pointer;flex:none;transition:transform .12s}
  .help-i:hover{transform:scale(1.08);background:var(--accent);color:#fff}
  .view{display:none}
  .view.active{display:block;animation:viewin .18s ease}
  @keyframes viewin{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}

  /* ---------- KPI cards ---------- */
  .kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px}
  .kpi{background:var(--card);border:1px solid var(--border);border-radius:15px;padding:15px 16px;position:relative;
    overflow:hidden;box-shadow:var(--shadow-1);transition:transform .14s, box-shadow .14s}
  .kpi:hover{transform:translateY(-2px);box-shadow:var(--shadow-2)}
  .kpi::before{content:'';position:absolute;left:0;top:12px;bottom:12px;width:3.5px;border-radius:0 4px 4px 0;
    background:linear-gradient(180deg,var(--accent),var(--accent-3))}
  .kpi .l{font-size:10.5px;color:var(--ink-3);text-transform:uppercase;letter-spacing:.7px;font-weight:700}
  .kpi .v{font-size:27px;font-weight:800;margin-top:7px;font-family:var(--font-head);letter-spacing:-.02em}

  /* ---------- Cards & tables ---------- */
  .card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:18px 20px;margin-bottom:18px;
    box-shadow:var(--shadow-1)}
  .card h3{font-size:13.5px;font-weight:800;margin-bottom:14px;display:flex;justify-content:space-between;
    align-items:center;gap:10px;flex-wrap:wrap;color:var(--accent-ink)}
  .card h3 .hint{font-size:10.5px;color:var(--ink-3);font-weight:600;font-family:'Inter',sans-serif;letter-spacing:0}
  table{width:100%;border-collapse:separate;border-spacing:0;font-size:12.5px}
  th{text-align:left;background:var(--accent-weak);color:var(--accent-ink);font-weight:700;font-size:10.5px;
    text-transform:uppercase;letter-spacing:.5px;padding:9px 10px;border-bottom:none}
  th:first-child{border-radius:9px 0 0 9px}
  th:last-child{border-radius:0 9px 9px 0}
  td{padding:10px;border-bottom:1px solid var(--hairline);color:var(--ink-2);vertical-align:middle}
  tr:last-child td{border-bottom:none}
  td b,td .nm{color:var(--ink);font-weight:600}
  tbody tr{transition:background .1s}
  tbody tr:hover td{background:var(--card-2)}
  .tag{font-size:10px;font-weight:700;padding:3.5px 10px;border-radius:12px;display:inline-block;white-space:nowrap}
  .t-ok{background:var(--ok-w);color:var(--ok)}
  .t-idle{background:var(--idle-w);color:var(--idle)}
  .t-warn{background:var(--warn-w);color:var(--warn)}
  .t-off{background:#EDF1F4;color:var(--ink-3)}
  .t-danger{background:var(--danger-w);color:var(--danger)}
  .t-info{background:var(--info-w);color:var(--info)}
  .clk{cursor:pointer}
  .clk:hover td{background:var(--accent-weak)!important}
  .btn{background:var(--card);border:1.5px solid var(--border);border-radius:9px;padding:7px 13px;font-size:12px;
    font-weight:700;color:var(--ink-2);cursor:pointer;font-family:inherit;transition:all .13s}
  .btn:hover{border-color:var(--accent);color:var(--accent);box-shadow:0 2px 8px rgba(14,124,143,.12)}
  .btn.acc{background:var(--accent-weak);color:var(--accent-ink);border-color:transparent}
  .btn.acc:hover{background:#D2ECF1}
  .btn.solid{background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;border-color:transparent;
    box-shadow:0 4px 12px rgba(14,124,143,.28)}
  .btn.solid:hover{color:#fff;transform:translateY(-1px);box-shadow:0 7px 16px rgba(14,124,143,.38)}
  .btn.danger{background:var(--danger-w);color:var(--danger);border-color:transparent}
  .btn.danger:hover{background:#F7D6DE;color:var(--danger);border-color:transparent}
  .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
  .filters{display:flex;gap:9px;flex-wrap:wrap;align-items:center;margin-bottom:16px;background:var(--card);
    border:1px solid var(--border);border-radius:13px;padding:11px 14px;box-shadow:var(--shadow-1)}
  .filters label{margin:0;white-space:nowrap}
  .filters input,.filters select{width:auto;min-width:150px;padding:8px 11px}
  .mut{color:var(--ink-3);font-size:12px;padding:10px 0}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:18px;align-items:start}
  .grid2 > .card{margin-bottom:0}
  @media(max-width:1100px){.grid2{grid-template-columns:1fr}.kpis{grid-template-columns:1fr 1fr}}

  /* ---------- Screenshots ---------- */
  .shots{display:grid;grid-template-columns:repeat(auto-fill,minmax(196px,1fr));gap:13px}
  .shotcard{border:1px solid var(--border);border-radius:12px;overflow:hidden;background:var(--card);cursor:pointer;
    transition:transform .13s, box-shadow .13s, border-color .13s;box-shadow:var(--shadow-1)}
  .shotcard:hover{border-color:var(--accent-2);transform:translateY(-2px);box-shadow:var(--shadow-2)}
  .shotcard .img{height:112px;background:linear-gradient(135deg,#E7EDF3,#F2F5F9);display:flex;align-items:center;
    justify-content:center;color:var(--ink-3);font-size:10px;font-weight:700;overflow:hidden}
  .shotcard .img img{width:100%;height:100%;object-fit:cover;display:block}
  .shotcard .m{padding:9px 11px;font-size:10.5px;color:var(--ink-2);line-height:1.5}
  .shotcard .m b{display:block;color:var(--ink);font-size:11px}
  .shotcard.ev-hit{outline:3px solid var(--warn);outline-offset:2px;animation:evpulse 1.6s ease 2}
  .shotcard.ev-hit::after{content:'⚠ VIOLATION EVIDENCE';display:block;background:var(--warn-w);color:var(--warn);
    font-size:9.5px;font-weight:800;letter-spacing:.6px;text-align:center;padding:4px}
  @keyframes evpulse{0%,100%{box-shadow:var(--shadow-1)}50%{box-shadow:0 0 0 8px rgba(183,121,31,.22)}}

  /* ---------- Overlays / modals ---------- */
  .ovl{position:fixed;inset:0;background:rgba(5,42,51,.55);backdrop-filter:blur(3px);display:none;align-items:center;
    justify-content:center;z-index:80;padding:20px}
  .ovl.open{display:flex;animation:viewin .15s ease}
  .modal{background:var(--card);border-radius:16px;width:640px;max-width:100%;max-height:88vh;display:flex;
    flex-direction:column;overflow:hidden;box-shadow:0 40px 110px rgba(0,0,0,.45)}
  .mhead{background:linear-gradient(135deg,var(--navy),var(--navy-2));color:#fff;padding:15px 20px;display:flex;align-items:center;gap:12px}
  .mhead b{font-size:14px;display:block;font-family:var(--font-head)}
  .mhead span{font-size:10.5px;color:#9FC5CC}
  .mhead .mt{flex:1}
  .mhead .x{background:rgba(255,255,255,.1);border:none;color:#fff;font-size:16px;cursor:pointer;font-family:inherit;
    width:30px;height:30px;border-radius:8px;transition:background .12s}
  .mhead .x:hover{background:rgba(255,255,255,.22)}
  .mbody{padding:18px 20px;overflow-y:auto;font-size:12.5px;line-height:1.65;color:var(--ink-2)}
  .mbody h5{font-size:12px;color:var(--accent-ink);margin:13px 0 5px;font-family:var(--font-head)}
  .mbody h5:first-child{margin-top:0}
  .mfoot{padding:13px 20px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:8px;background:var(--card-2)}
  .shotbig{max-width:92vw;max-height:78vh;border-radius:12px;display:block;background:#fff;box-shadow:0 30px 80px rgba(0,0,0,.5)}
  .shotmeta{color:#fff;font-size:12px;text-align:center;margin-top:10px}

  /* ---------- Forms ---------- */
  .fgrid{display:grid;grid-template-columns:1fr 1fr;gap:0 16px}
  .fgrid .full{grid-column:1 / -1}
  .fbool{display:flex;align-items:center;gap:9px;padding:9px 2px 0;font-size:12.5px;color:var(--ink-2);font-weight:600}
  textarea{min-height:64px;resize:vertical;font-size:12px}
  .search{min-width:220px}

  /* ---------- Policies ---------- */
  .never{background:var(--danger-w);border:1px solid #F3C2CE;border-left:4px solid var(--danger);border-radius:12px;
    padding:14px 16px;font-size:12px;color:var(--ink-2);margin-bottom:16px}
  .never b{color:var(--danger);display:block;margin-bottom:7px;font-size:12px}
  .never ul{margin:0 0 0 18px;line-height:1.8}

  /* ---------- Reports ---------- */
  .exp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:15px}
  .exp{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:17px;box-shadow:var(--shadow-1);
    transition:transform .13s, box-shadow .13s;position:relative;overflow:hidden}
  .exp::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--accent),var(--accent-3));opacity:0;transition:opacity .13s}
  .exp:hover{transform:translateY(-2px);box-shadow:var(--shadow-2)}
  .exp:hover::before{opacity:1}
  .exp b{font-size:13px;font-family:var(--font-head)}
  .exp p{font-size:11.5px;color:var(--ink-3);margin:7px 0 11px;line-height:1.55}
  .exp .row input{min-width:0;width:auto;flex:1;padding:8px 10px}

  /* ---------- Drawer ---------- */
  .drawer{position:fixed;top:0;right:0;width:530px;max-width:92vw;height:100vh;background:var(--card);border-left:1px solid var(--border);
    box-shadow:-24px 0 60px rgba(5,42,51,.18);padding:22px;overflow-y:auto;transform:translateX(100%);
    transition:transform .22s cubic-bezier(.2,.8,.3,1);z-index:20;border-radius:18px 0 0 18px}
  .drawer.open{transform:none}
  .drawer .x{float:right;cursor:pointer;color:var(--ink-3);font-size:18px;width:30px;height:30px;text-align:center;
    line-height:30px;border-radius:8px;transition:background .12s}
  .drawer .x:hover{background:var(--card-2);color:var(--ink)}
  .tabs{display:flex;gap:6px;margin:14px 0}
  .tab{font-size:11.5px;padding:7px 13px;border-radius:9px;background:var(--card-2);border:1.5px solid var(--border);
    cursor:pointer;color:var(--ink-2);font-weight:700;transition:all .12s}
  .tab:hover{border-color:var(--accent-2);color:var(--accent-ink)}
  .tab.active{background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;border-color:transparent;
    box-shadow:0 3px 10px rgba(14,124,143,.3)}
  .tl{border-left:2px solid var(--accent-weak);margin-left:6px;padding-left:15px}
  .tl .ev{position:relative;padding:7px 0;font-size:12px}
  .tl .ev::before{content:'';position:absolute;left:-20px;top:11px;width:8px;height:8px;border-radius:50%;
    background:var(--accent-2);box-shadow:0 0 0 3px var(--accent-weak)}
  .tl .ev .tm{color:var(--ink-3);font-size:10.5px;margin-right:8px;font-variant-numeric:tabular-nums}

  /* ---------- Empty / denied ---------- */
  .denied{text-align:center;padding:44px 20px;color:var(--ink-3)}
  .denied .big{font-size:32px;margin-bottom:10px}
  .empty{border:1.5px dashed #C9D6DE;border-radius:14px;padding:38px 22px;text-align:center;color:var(--ink-3);
    font-size:12.5px;line-height:1.75;background:var(--card-2)}
  .empty b{color:var(--ink-2)}
</style>
</head>
<body>

<!-- LOGIN -->
<div class="login" id="login">
  <div class="box">
    <div class="lock"><div class="mark">EPT</div><div><h1>SmartEPT</h1><small>BY AMETECS</small></div></div>
    <label>Work email</label><input id="email" type="email" value="admin@ametecs.io">
    <label>Password</label><input id="password" type="password" value="password">
    <button class="primary" id="btn-login">Sign in</button>
    <div class="err" id="login-err"></div>
  </div>
</div>

<!-- APP -->
<div class="shell hide" id="app">
  <div class="side">
    <div class="lock"><div class="mark">EPT</div><div><h1 style="font-size:15px">SmartEPT</h1><small>BY AMETECS</small></div></div>
    <div class="navgrp">MONITOR</div>
    <div class="nav active" data-view="dashboard"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7.5" height="7.5" rx="1.6"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1.6"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1.6"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.6"/></svg></span> Live Dashboard</div>
    <div class="nav" data-view="attendance"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.6"/><path d="M12 7.4V12l3.2 1.9"/></svg></span> Attendance</div>
    <div class="nav" data-view="screenshots"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4.5" width="18" height="13" rx="2"/><path d="M8.5 21h7M12 17.5V21"/><circle cx="9" cy="9.4" r="1.5"/><path d="M21 14.5l-4.2-4.2-5.3 5.2"/></svg></span> Screenshots</div>
    <div class="nav" data-view="usage"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12A9 9 0 1 1 12 3"/><path d="M12 3a9 9 0 0 1 9 9h-9z"/></svg></span> Usage &amp; Compliance</div>
    <div class="nav" data-view="violations"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M10.3 4.1 2.9 17a2 2 0 0 0 1.7 3h14.8a2 2 0 0 0 1.7-3L13.7 4.1a2 2 0 0 0-3.4 0z"/><path d="M12 9.5v4.2M12 16.9h.01"/></svg></span> Violations</div>
    <div class="navgrp">MANAGE</div>
    <div class="nav" data-view="employees"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8.2" r="3.4"/><path d="M2.8 20.2a6.2 6.2 0 0 1 12.4 0"/><circle cx="17.2" cy="9.4" r="2.6"/><path d="M16 15.6a5 5 0 0 1 5.2 4.6"/></svg></span> Employees</div>
    <div class="nav" data-view="users"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8.4" r="3.6"/><path d="M4.8 20.4a7.2 7.2 0 0 1 14.4 0"/></svg></span> Users</div>
    <div class="nav" data-view="devices"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4.5" width="18" height="12.5" rx="2"/><path d="M8.5 21h7M12 17v4"/></svg></span> Devices</div>
    <div class="nav" data-view="policies"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l7.5 3v5.2c0 4.8-3.2 8.2-7.5 9.8-4.3-1.6-7.5-5-7.5-9.8V6z"/><path d="M9 11.8l2.1 2.1 3.9-4.2"/></svg></span> Policies</div>
    <div class="nav" data-view="biometric"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M7 4.8A9 9 0 0 1 21 12c0 2.6-.4 5-1.2 7"/><path d="M3.6 8.4A9 9 0 0 0 3 12c0 2.8.6 5.2 1.6 7.2"/><path d="M12 8.4a3.6 3.6 0 0 1 3.6 3.6c0 2.3-.3 4.5-1 6.6"/><path d="M8.4 12a3.6 3.6 0 0 1 .4-1.7M8.6 15.6c.3 1.5.2 3-.2 4.6"/><path d="M12 12v2.4c0 1.7-.2 3.4-.7 5"/></svg></span> Biometric</div>
    <div class="navgrp">INSIGHT</div>
    <div class="nav" data-view="reports"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v11.5M7.5 10l4.5 4.5L16.5 10"/><path d="M4 17v2.4A1.6 1.6 0 0 0 5.6 21h12.8a1.6 1.6 0 0 0 1.6-1.6V17"/></svg></span> Reports &amp; Exports</div>
    <div class="nav" data-view="license"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="12" r="4.6"/><path d="M12.6 12H21M17.5 12v3.4M21 12v2.4"/></svg></span> Licence</div>
    <div class="nav" data-view="ops"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12h4l2.5-6.5 5 13L17 12h4"/></svg></span> Audit &amp; Ops</div>
    <div class="foot"><span id="who"></span><br><a id="signout" style="color:var(--ink-3);cursor:pointer">Sign out</a></div>
  </div>
  <div class="main">
    <div class="top">
      <div><h2 id="page-title">Live Dashboard</h2><div class="sub" id="page-sub">Real-time workforce status</div></div>
      <div class="who"><span id="company-name">Ametecs Pvt Ltd</span><button class="help-i" id="btn-help" title="About this screen">ⓘ</button></div>
    </div>

    <!-- 1. DASHBOARD -->
    <div class="view active" id="v-dashboard">
      <div class="kpis" id="kpis"></div>
      <div class="card">
        <h3>Employees — live
          <span class="row">
            <span class="hint">auto-refreshes every 15s · click a row for detail</span>
            <button class="btn" data-export="productivity">Export productivity CSV</button>
            <button class="btn" data-export="attendance">Export attendance CSV</button>
          </span>
        </h3>
        <table><thead><tr><th>Employee</th><th>Team</th><th>Status</th><th>Active</th><th>Idle</th><th>Last seen</th></tr></thead>
        <tbody id="live-rows"></tbody></table>
      </div>
      <div class="card">
        <h3>Device health <span class="hint">agent heartbeat · sync queue · compliance</span></h3>
        <table><thead><tr><th>Device</th><th>Employee</th><th>Agent ver</th><th>Agent</th><th>Compliance</th><th>Sync queue</th><th>Last heartbeat</th></tr></thead>
        <tbody id="dash-dev-rows"></tbody></table>
      </div>
    </div>

    <!-- 1b. ATTENDANCE -->
    <div class="view" id="v-attendance">
      <div class="filters">
        <label>Date</label><input type="date" id="at-date" style="min-width:0">
        <label>Status</label><select id="at-status">
          <option value="">All statuses</option><option value="PRESENT">PRESENT</option><option value="ABSENT">ABSENT</option>
          <option value="HALF_DAY">HALF_DAY</option><option value="ON_LEAVE">ON_LEAVE</option>
        </select>
        <button class="btn acc" id="at-load">Load</button>
        <button class="btn solid" id="at-add" style="margin-left:auto">+ Add missed day</button>
      </div>
      <div class="card">
        <h3>Attendance sheet <span class="hint">corrections require a reason and are audit-logged — they feed payroll</span></h3>
        <table><thead><tr><th>Employee</th><th>Status</th><th>Check-in</th><th>Check-out</th><th>Late (min)</th><th>Source</th><th>Notes</th><th></th></tr></thead>
        <tbody id="at-rows"></tbody></table>
      </div>
      <div class="card">
        <h3>Holiday calendar
          <span class="row">
            <span class="hint">no late/absent marking on these days · HD in the register</span>
            <select id="hol-year" style="width:auto;min-width:90px;padding:6px 9px"></select>
          </span>
        </h3>
        <table><thead><tr><th>Date</th><th>Name</th><th>Type</th><th></th></tr></thead><tbody id="hol-rows"></tbody></table>
        <div class="row" style="margin-top:12px">
          <input type="date" id="hol-date" style="width:auto">
          <input id="hol-name" placeholder="Holiday name, e.g. Republic Day" style="width:auto;min-width:220px;flex:1">
          <select id="hol-type" style="width:auto"><option value="PUBLIC">PUBLIC</option><option value="COMPANY">COMPANY</option></select>
          <button class="btn solid" id="hol-add">Add holiday</button>
        </div>
        <div class="mut" id="hol-msg"></div>
      </div>
    </div>

    <!-- 2. SCREENSHOTS -->
    <div class="view" id="v-screenshots">
      <div class="filters">
        <label>Employee</label><select id="ss-emp"></select>
        <label>Date</label><input type="date" id="ss-date" style="min-width:0">
        <button class="btn acc" id="ss-load">Load</button>
        <span class="tag t-info" style="margin-left:auto">EVERY VIEW IS AUDIT-LOGGED</span>
      </div>
      <div class="card">
        <h3 id="ss-title">Screenshot timeline</h3>
        <div id="ss-grid" class="shots"></div>
        <div id="ss-empty" class="hide"></div>
      </div>
    </div>

    <!-- 3. USAGE & COMPLIANCE -->
    <div class="view" id="v-usage">
      <div class="filters">
        <label>Employee</label><select id="us-emp"></select>
        <label>Date</label><input type="date" id="us-date" style="min-width:0">
        <button class="btn acc" id="us-load">Load</button>
        <button class="btn" id="us-open-drawer">Open full profile</button>
      </div>
      <div class="grid2">
        <div class="card">
          <h3>Application usage</h3>
          <table><thead><tr><th>App</th><th>Category</th><th>Time</th><th>Status</th></tr></thead><tbody id="us-app-rows"></tbody></table>
        </div>
        <div class="card">
          <h3>Website usage <span class="hint">MVP: site from browser window title</span></h3>
          <table><thead><tr><th>Site</th><th>Category</th><th>Time</th><th>Status</th></tr></thead><tbody id="us-web-rows"></tbody></table>
        </div>
      </div>
      <div class="card" style="margin-top:16px">
        <h3>Compliance events (selected day)</h3>
        <table><thead><tr><th>Time</th><th>Type</th><th>Severity</th><th>Detected</th><th>Action taken</th></tr></thead><tbody id="us-comp-rows"></tbody></table>
      </div>
    </div>

    <!-- 4. VIOLATIONS -->
    <div class="view" id="v-violations">
      <div class="card"><h3>Compliance violations
        <button class="btn" data-export="compliance">Export CSV</button></h3>
        <table><thead><tr><th>Time</th><th>Employee</th><th>Category</th><th>Type</th><th>Severity</th><th>Detected</th><th>Action taken</th><th>Evidence</th></tr></thead>
        <tbody id="viol-rows"></tbody></table>
      </div>
    </div>

    <!-- 5. EMPLOYEES -->
    <div class="view" id="v-employees">
      <div class="filters">
        <input id="emp-q" class="search" placeholder="Search name / code…" style="min-width:220px">
        <button class="btn" id="emp-template" style="margin-left:auto">Download CSV template</button>
        <button class="btn acc" id="emp-import">Bulk import (CSV)</button>
        <button class="btn solid" id="emp-add">+ Add employee</button>
      </div>
      <div class="card"><h3>All employees</h3>
        <table><thead><tr><th>Code</th><th>Name</th><th>Email</th><th>Department</th><th>Team</th><th>Shift</th><th>Status</th><th>Devices</th><th></th></tr></thead>
        <tbody id="emp-rows"></tbody></table>
      </div>
    </div>

    <!-- 5b. USERS -->
    <div class="view" id="v-users">
      <div class="filters">
        <input id="u-q" placeholder="Search name / email…" style="min-width:220px">
        <button class="btn solid" id="u-add" style="margin-left:auto">+ Add user</button>
      </div>
      <div class="card"><h3>Login accounts <span class="hint">console &amp; self-service logins — separate from the employee directory</span></h3>
        <table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Linked employee</th><th>Status</th><th>Last login</th><th></th></tr></thead>
        <tbody id="u-rows"></tbody></table>
      </div>
    </div>

    <!-- 6. DEVICES -->
    <div class="view" id="v-devices">
      <div class="card"><h3>Registered devices &amp; agent health</h3>
        <table><thead><tr><th>Device</th><th>Employee</th><th>OS</th><th>Agent ver</th><th>Agent health</th><th>Compliance</th><th>Status</th><th>Sync queue</th><th>Last heartbeat</th><th></th></tr></thead>
        <tbody id="dev-rows"></tbody></table>
      </div>
    </div>

    <!-- 7. POLICIES -->
    <div class="view" id="v-policies">
      <div class="filters">
        <label>Policy type</label><select id="pol-type"></select>
        <button class="btn solid" id="pol-new" style="margin-left:auto">+ New policy</button>
      </div>
      <div class="grid2">
        <div>
          <div class="card">
            <h3 id="pol-list-title">Policies <span class="hint">editing bumps the version — agents pick it up on next heartbeat</span></h3>
            <table><thead><tr><th>Name</th><th>Version</th><th>Updated</th><th></th></tr></thead><tbody id="pol-rows"></tbody></table>
          </div>
          <div class="never">
            <b>⛔ NEVER captured — locked at product level (cannot be switched on by anyone)</b>
            <ul>
              <li>Keystrokes, passwords, clipboard contents</li>
              <li>Personal files, documents, emails content</li>
              <li>Banking / UPI / payment apps &amp; sites (auto-excluded from screenshots and usage)</li>
              <li>Anything outside duty hours — tracking hard-stops at Duty End / shift end</li>
              <li>Webcam video or audio recording — presence is a yes/no signal only</li>
            </ul>
          </div>
        </div>
        <div>
          <div class="card" id="pol-form-card">
            <h3 id="pol-form-title">Create policy</h3>
            <div id="pol-form" class="fgrid"></div>
            <div class="row" style="margin-top:14px;justify-content:flex-end">
              <button class="btn" id="pol-cancel">Reset</button>
              <button class="btn solid" id="pol-save">Save policy</button>
            </div>
            <div class="err" id="pol-err"></div>
          </div>
          <div class="card" style="margin-top:16px">
            <h3>Assign a policy <span class="hint">precedence: device › employee › team › dept › branch › company</span></h3>
            <div class="fgrid">
              <div><label>Policy</label><select id="as-policy"></select></div>
              <div><label>Assign to (level)</label><select id="as-type">
                <option value="COMPANY">Company</option><option value="BRANCH">Branch</option>
                <option value="DEPARTMENT">Department</option><option value="TEAM">Team</option>
                <option value="EMPLOYEE">Employee</option><option value="DEVICE">Device</option>
              </select></div>
              <div class="full"><label>Target</label><select id="as-target"></select></div>
              <div><label>Effective from (optional)</label><input type="date" id="as-from"></div>
              <div><label>Effective to (optional)</label><input type="date" id="as-to"></div>
            </div>
            <div class="row" style="margin-top:14px;justify-content:flex-end">
              <button class="btn solid" id="as-save">Assign</button>
            </div>
            <div class="mut" id="as-log"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- 8. BIOMETRIC -->
    <div class="view" id="v-biometric">
      <div class="filters">
        <label>Date</label><input type="date" id="bio-date" style="min-width:0">
        <button class="btn acc" id="bio-load">Load</button>
      </div>
      <div class="card">
        <h3>Registered punch devices <span class="hint">the physical readers at gates &amp; doors</span></h3>
        <table><thead><tr><th>Name</th><th>Serial</th><th>Location</th><th>IP</th><th>Method</th><th>Vendor</th><th>Status</th><th>Last sync</th><th>Punches</th><th></th></tr></thead><tbody id="biodev-rows"></tbody></table>
        <div class="grid2" style="margin-top:14px">
          <div>
            <label>Device name *</label><input id="bd-name" placeholder="e.g. Main Gate Reader">
            <label>Serial number</label><input id="bd-serial" placeholder="e.g. ZK-58231">
            <label>Location</label><input id="bd-loc" placeholder="e.g. Head Office — Main Gate">
            <label>IP address</label><input id="bd-ip" placeholder="e.g. 192.168.1.201">
          </div>
          <div>
            <label>Integration method</label>
            <select id="bd-method"><option>MIDDLEWARE_PUSH</option><option>CSV_IMPORT</option><option>DIRECT_PULL</option><option>HRMS_API</option></select>
            <label>Vendor</label><input id="bd-vendor" placeholder="e.g. ZKTeco / eSSL / Realtime">
            <label>Status</label><select id="bd-status"><option>ACTIVE</option><option>INACTIVE</option></select>
            <div class="row" style="margin-top:12px;justify-content:flex-end">
              <button class="btn" id="bd-reset">Clear</button>
              <button class="btn solid" id="bd-save">Add device</button>
            </div>
            <div class="mut" id="bd-msg"></div>
          </div>
        </div>
      </div>
      <div class="card">
        <h3>Punch log <span class="hint">from device middleware push or CSV import</span></h3>
        <table><thead><tr><th>Time</th><th>Employee</th><th>Bio ID</th><th>Punch</th><th>Mode</th></tr></thead><tbody id="bio-rows"></tbody></table>
      </div>
      <div class="card">
        <h3>Biometric vs system login — mismatch report</h3>
        <table><thead><tr><th>Employee</th><th>Biometric IN</th><th>Agent login</th><th>Gap (min)</th><th>Status</th></tr></thead><tbody id="bio-mm-rows"></tbody></table>
      </div>
      <div class="grid2">
        <div class="card">
          <h3>Import punches (CSV)</h3>
          <div class="mut" style="padding-top:0">Columns: <b>biometric_employee_id, punch_type, punched_at</b> (header row required).</div>
          <input type="file" id="bio-file" accept=".csv,.txt" style="padding:8px">
          <div class="row" style="margin-top:12px;justify-content:flex-end"><button class="btn solid" id="bio-import">Import</button></div>
          <div class="mut" id="bio-import-msg"></div>
        </div>
        <div class="card">
          <h3>Map biometric ID → employee</h3>
          <label>Biometric employee ID (as on the device)</label><input id="bio-map-id" placeholder="e.g. 1043">
          <label>SmartEPT employee</label><select id="bio-map-emp"></select>
          <div class="row" style="margin-top:12px;justify-content:flex-end"><button class="btn solid" id="bio-map-save">Map</button></div>
          <div class="mut" id="bio-map-msg"></div>
        </div>
      </div>
    </div>

    <!-- 9. REPORTS & EXPORTS -->
    <div class="view" id="v-reports">
      <div class="exp-grid">
        <div class="exp"><b>Attendance report</b>
          <p>Punch in/out, agent login, late marks, source — day-wise per employee. CSV opens directly in Excel.</p>
          <div class="row"><input type="date" id="rp-att-from"><input type="date" id="rp-att-to"></div>
          <div class="row" style="margin-top:10px"><button class="btn acc" id="rp-att">⇓ Export CSV</button></div>
        </div>
        <div class="exp"><b>Productivity report</b>
          <p>Active vs idle vs break hours per employee over a date range — the raw material for productivity %.</p>
          <div class="row"><input type="date" id="rp-prod-from"><input type="date" id="rp-prod-to"></div>
          <div class="row" style="margin-top:10px"><button class="btn acc" id="rp-prod">⇓ Export CSV</button></div>
        </div>
        <div class="exp"><b>Compliance report</b>
          <p>Violations by employee &amp; type, severity, detected value and the action the agent took.</p>
          <div class="row"><input type="date" id="rp-comp-from"><input type="date" id="rp-comp-to"></div>
          <div class="row" style="margin-top:10px"><button class="btn acc" id="rp-comp">⇓ Export CSV</button></div>
        </div>
        <div class="exp"><b>Daily summary (scoring)</b>
          <p>Nightly per-employee rollup over a date range: hours, violations, productivity &amp; compliance scores (0–100).</p>
          <div class="row"><input type="date" id="rp-sum-from"><input type="date" id="rp-sum-to"></div>
          <div class="row" style="margin-top:10px"><button class="btn acc" id="rp-sum">⇓ Export CSV</button></div>
        </div>
        <div class="exp"><b>Attendance register (monthly)</b>
          <p>The classic month matrix — one row per employee, one letter per day (P/A/H/L, WO weekly off, HD holiday) with payable-day totals.</p>
          <div class="row"><input type="month" id="rp-reg-month"></div>
          <div class="row" style="margin-top:10px"><button class="btn acc" id="rp-reg">⇓ Export CSV</button></div>
        </div>
        <div class="exp"><b>Monthly summary</b>
          <p>Per-employee month rollup: working days, P/A/H/L counts, payable days and average productivity — rendered right here.</p>
          <div class="row"><input type="month" id="rp-ms-month"></div>
          <div class="row" style="margin-top:10px"><button class="btn acc" id="rp-ms">View summary</button></div>
        </div>
      </div>
      <div class="mut" id="rp-msg"></div>
      <div class="card hide" id="ms-card">
        <h3 id="ms-title">Monthly summary <span class="hint">payable days = present + 0.5 × half-day + paid leave</span></h3>
        <table><thead><tr><th>Code</th><th>Employee</th><th>Working days</th><th>P</th><th>A</th><th>H</th><th>L</th><th>Payable days</th><th>Avg productivity</th></tr></thead>
        <tbody id="ms-rows"></tbody></table>
      </div>
    </div>

    <!-- 12. LICENCE (R2-1) -->
    <div class="view" id="v-license">
      <div class="card"><h3>Licence status <span class="hint">this server validates with SmartEPT Central once a day — licence metadata only, never monitoring data</span></h3>
        <div id="lic-status" class="mut">Loading…</div>
      </div>
      <div class="card"><h3>Licence key</h3>
        <div class="filters">
          <input id="lic-key" placeholder="SEPT-XXXX-XXXX-XXXX-XXXX" style="min-width:300px;text-transform:uppercase">
          <button class="btn solid" id="lic-save">Save &amp; validate</button>
          <button class="btn" id="lic-check">Validate now</button>
        </div>
        <div class="mut" id="lic-msg">Paste the key from your SmartEPT order email or the client portal (Billing &amp; Licences). Without a key the server runs a 7-day free evaluation, then monitoring stops until a key is entered.</div>
      </div>
    </div>

    <!-- 13. AUDIT & OPS (R2-4) -->
    <div class="view" id="v-ops">
      <div class="exp-grid">
        <div class="exp"><b>Storage usage</b>
          <p>Screenshot &amp; webcam evidence on disk, per company — watch this before it surprises you.</p>
          <div id="ops-storage" class="mut">…</div>
          <div class="row" style="margin-top:10px"><button class="btn danger" id="ops-cleanup">Free up storage…</button></div>
        </div>
        <div class="exp"><b>Database backups</b>
          <p>Nightly at 01:30, newest 14 kept in <code>storage/app/backups</code>. You can also run one right now.</p>
          <div id="ops-backups" class="mut">…</div>
          <div class="row" style="margin-top:10px"><button class="btn acc" id="ops-backup-now">Back up now</button><span class="mut" id="ops-backup-msg"></span></div>
        </div>
      </div>
      <div class="card"><h3>Audit trail <span class="hint">every admin action, export and screenshot view — accountable and searchable</span></h3>
        <div class="filters">
          <input id="au-action" placeholder="Action contains… e.g. DELETE, EXPORT, LOGIN" style="min-width:240px">
          <input type="date" id="au-from"><input type="date" id="au-to">
          <button class="btn" id="au-go">Search</button>
        </div>
        <table><thead><tr><th>When</th><th>User</th><th>Action</th><th>Subject</th><th>Details</th><th>IP</th></tr></thead>
        <tbody id="au-rows"></tbody></table>
      </div>
    </div>
  </div>
</div>

<!-- BULK EMPLOYEE IMPORT (17-Jul, SmartPRS parity) -->
<div class="ovl" id="import-ovl">
  <div class="modal" style="width:640px">
    <div class="mhead"><div class="mt"><b>Bulk import employees</b><span>Upload a CSV — one row per employee. Departments, teams, branches, shifts &amp; designations are matched by name and created if new.</span></div>
      <button class="x" id="import-x">&#10005;</button></div>
    <div class="mbody">
      <div class="never" style="background:var(--accent-weak);border-color:var(--accent);margin-bottom:14px">
        <b style="color:var(--accent-ink)">CSV columns</b>
        <div style="font-size:11.5px;line-height:1.7">
          <b>Required:</b> employee_code, first_name<br>
          <b>Optional:</b> last_name, email, mobile, department, team, branch, designation, shift, date_of_joining, biometric_id<br>
          A login is created for every row that has an email (opt out below). Download the template for the exact header row.
        </div>
      </div>
      <label>Choose CSV file</label>
      <input type="file" id="import-file" accept=".csv,text/csv">
      <div class="fbool" style="margin-top:10px"><input type="checkbox" id="import-login" checked> Create a self-service login for each employee with an email</div>
      <div class="row" style="margin-top:14px">
        <button class="btn" id="import-preview">Preview (dry run)</button>
        <button class="btn solid" id="import-run" disabled>Import now</button>
      </div>
      <div id="import-result" style="margin-top:14px;font-size:12px"></div>
    </div>
  </div>
</div>

<!-- STORAGE CLEANUP (17-Jul): bulk delete evidence & logs by date range -->
<div class="ovl" id="cleanup-ovl">
  <div class="modal" style="width:560px">
    <div class="mhead"><div class="mt"><b>Free up storage — bulk delete</b><span>Deletes are permanent and audit-logged. Attendance, breaks and the audit trail are never touched.</span></div>
      <button class="x" id="cleanup-x">✕</button></div>
    <div class="mbody">
      <div class="fgrid">
        <div><label>From date</label><input type="date" id="cl-from"></div>
        <div><label>To date</label><input type="date" id="cl-to"></div>
      </div>
      <label style="margin-top:14px">What to delete in this range</label>
      <div class="fbool"><input type="checkbox" id="cl-shots" checked> Screenshots (frees disk space)</div>
      <div class="fbool"><input type="checkbox" id="cl-activity"> Activity events (active/idle stretches)</div>
      <div class="fbool"><input type="checkbox" id="cl-apps"> Application usage logs</div>
      <div class="fbool"><input type="checkbox" id="cl-sites"> Website usage logs</div>
      <div class="fbool"><input type="checkbox" id="cl-presence"> Webcam presence logs</div>
      <div class="never" style="margin-top:14px;margin-bottom:0">
        <b>Violation evidence protection</b>
        <div class="fbool" style="padding-top:2px"><input type="checkbox" id="cl-keepviol" checked> Keep violation screenshots (recommended — evidence survives cleanup)</div>
        <div class="fbool"><input type="checkbox" id="cl-delviol"> Also delete violation RECORDS in this range (needs the confirmation word)</div>
      </div>
      <label style="margin-top:14px">Type <b>DELETE</b> to confirm</label>
      <input id="cl-confirm" placeholder="DELETE" autocomplete="off">
      <div class="mut" id="cl-msg" style="min-height:18px"></div>
    </div>
    <div class="mfoot">
      <button class="btn" id="cleanup-cancel">Cancel</button>
      <button class="btn danger" id="cleanup-run">Delete permanently</button>
    </div>
  </div>
</div>

<!-- EMPLOYEE DRAWER -->
<div class="drawer" id="drawer">
  <span class="x" id="drawer-x">✕</span>
  <h2 id="d-name" style="font-size:17px">Employee</h2>
  <div class="sub" id="d-sub" style="color:var(--ink-3);font-size:12px"></div>
  <div class="tabs">
    <div class="tab active" data-tab="timeline">Timeline</div>
    <div class="tab" data-tab="apps">Apps</div>
    <div class="tab" data-tab="sites">Websites</div>
    <div class="tab" data-tab="compliance">Compliance</div>
  </div>
  <div id="d-body"></div>
</div>

<!-- HELP MODAL -->
<div class="ovl" id="help-ovl">
  <div class="modal">
    <div class="mhead">
      <div class="mark" style="width:30px;height:30px;font-size:10px;border-radius:8px">EPT</div>
      <div class="mt"><b id="help-title">Screen help</b><span>SmartEPT · what this screen does and how to use it</span></div>
      <button class="x" data-close="help-ovl">✕</button>
    </div>
    <div class="mbody" id="help-body"></div>
  </div>
</div>

<!-- EMPLOYEE ADD/EDIT MODAL -->
<div class="ovl" id="emp-ovl">
  <div class="modal">
    <div class="mhead">
      <div class="mt"><b id="emp-m-title">Add employee</b><span>Employee record · monitored via the desktop agent after device registration</span></div>
      <button class="x" data-close="emp-ovl">✕</button>
    </div>
    <div class="mbody">
      <div class="fgrid">
        <div><label>First name *</label><input id="f-first"></div>
        <div><label>Last name</label><input id="f-last"></div>
        <div><label>Employee code *</label><input id="f-code" placeholder="EMP001"></div>
        <div><label>Email</label><input id="f-email" type="email"></div>
        <div><label>Mobile</label><input id="f-mobile"></div>
        <div><label>Status</label><select id="f-status">
          <option value="ACTIVE">ACTIVE</option><option value="ON_LEAVE">ON_LEAVE</option><option value="RELIEVED">RELIEVED</option>
        </select></div>
        <div><label>Branch</label><select id="f-branch"></select></div>
        <div><label>Department</label><select id="f-dept"></select></div>
        <div><label>Team</label><select id="f-team"></select></div>
        <div><label>Designation</label><select id="f-desig"></select></div>
        <div><label>Shift</label><select id="f-shift"></select></div>
        <div><label>Date of joining</label><input id="f-doj" type="date"></div>
        <div class="full"><label>Biometric ID (optional)</label><input id="f-bio" placeholder="ID on the punch device"></div>
      </div>
      <div class="err" id="emp-m-err"></div>
    </div>
    <div class="mfoot">
      <button class="btn" data-close="emp-ovl">Cancel</button>
      <button class="btn solid" id="emp-m-save">Save</button>
    </div>
  </div>
</div>

<!-- USER ADD/EDIT MODAL -->
<div class="ovl" id="user-ovl">
  <div class="modal" style="width:540px">
    <div class="mhead">
      <div class="mt"><b id="u-m-title">Add user</b><span>Login account · a temporary password is generated and shown once</span></div>
      <button class="x" data-close="user-ovl">✕</button>
    </div>
    <div class="mbody">
      <div class="fgrid">
        <div><label>Full name *</label><input id="uf-name"></div>
        <div><label>Email *</label><input id="uf-email" type="email"></div>
        <div><label>Role *</label><select id="uf-role"></select></div>
        <div><label>Status</label><select id="uf-status"><option value="ACTIVE">ACTIVE</option><option value="DISABLED">DISABLED</option></select></div>
        <div class="full"><label>Linked employee (optional — set at creation only)</label><select id="uf-emp"></select></div>
      </div>
      <div class="err" id="u-m-err"></div>
    </div>
    <div class="mfoot">
      <button class="btn" data-close="user-ovl">Cancel</button>
      <button class="btn solid" id="u-m-save">Save</button>
    </div>
  </div>
</div>

<!-- ONE-TIME CREDENTIALS PANEL -->
<div class="ovl" id="cred-ovl">
  <div class="modal" style="width:480px">
    <div class="mhead">
      <div class="mt"><b>One-time credentials</b><span>Share these with the user — shown only once</span></div>
    </div>
    <div class="mbody">
      <div class="never" style="margin-bottom:14px"><b>⚠ Shown only once</b>
        Only a hash of this password is stored — once this box closes it cannot be retrieved, only reset. The user must change it at first sign-in.</div>
      <label>Email</label><input id="cred-email" readonly>
      <label>Temporary password</label>
      <div class="row" style="flex-wrap:nowrap">
        <input id="cred-pass" readonly style="font-family:ui-monospace,Menlo,Consolas,monospace;font-weight:700;font-size:15px;letter-spacing:1px">
        <button class="btn acc" id="cred-copy" style="white-space:nowrap">Copy</button>
      </div>
      <div class="mut" id="cred-msg"></div>
    </div>
    <div class="mfoot"><button class="btn solid" data-close="cred-ovl">Done — I've shared it</button></div>
  </div>
</div>

<!-- ATTENDANCE REGULARIZE / ADD MODAL -->
<div class="ovl" id="att-ovl">
  <div class="modal" style="width:560px">
    <div class="mhead">
      <div class="mt"><b id="att-m-title">Regularize attendance</b><span>Corrections feed payroll — a reason is required and audit-logged</span></div>
      <button class="x" data-close="att-ovl">✕</button>
    </div>
    <div class="mbody">
      <div class="fgrid">
        <div><label>Employee *</label><select id="af-emp"></select></div>
        <div><label>Date *</label><input type="date" id="af-date"></div>
        <div><label>Status *</label><select id="af-status">
          <option value="PRESENT">PRESENT</option><option value="ABSENT">ABSENT</option>
          <option value="HALF_DAY">HALF_DAY</option><option value="ON_LEAVE">ON_LEAVE</option>
        </select></div>
        <div></div>
        <div><label>Check-in (optional)</label><input type="datetime-local" id="af-in"></div>
        <div><label>Check-out (optional)</label><input type="datetime-local" id="af-out"></div>
        <div class="full"><label>Reason * — kept on the record with your name</label>
          <textarea id="af-reason" placeholder="e.g. Biometric reader was down — verified with the branch manager"></textarea></div>
      </div>
      <div class="err" id="att-m-err"></div>
    </div>
    <div class="mfoot">
      <button class="btn" data-close="att-ovl">Cancel</button>
      <button class="btn solid" id="att-m-save">Save</button>
    </div>
  </div>
</div>

<!-- FORCED PASSWORD CHANGE (not dismissible) -->
<div class="ovl" id="pwd-ovl">
  <div class="modal" style="width:420px">
    <div class="mhead">
      <div class="mt"><b>Set a new password</b><span>You signed in with a temporary password — choose your own to continue</span></div>
    </div>
    <div class="mbody">
      <label>Current (temporary) password</label><input type="password" id="pw-cur" autocomplete="current-password">
      <label>New password (min 8 characters)</label><input type="password" id="pw-new" autocomplete="new-password">
      <label>Confirm new password</label><input type="password" id="pw-conf" autocomplete="new-password">
      <div class="err" id="pw-err"></div>
    </div>
    <div class="mfoot">
      <button class="btn" id="pw-signout">Sign out</button>
      <button class="btn solid" id="pw-save">Change password &amp; continue</button>
    </div>
  </div>
</div>

<!-- SCREENSHOT LIGHTBOX -->
<div class="ovl" id="shot-ovl">
  <div style="max-width:92vw">
    <img class="shotbig" id="shot-img" alt="Screenshot">
    <div class="shotmeta" id="shot-meta"></div>
  </div>
</div>

@verbatim
<script>
const API = '/api';
let TOKEN = null, ME = null, CURRENT = null, poll = null;

const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

async function api(path, opts = {}) {
  const isForm = opts.body instanceof FormData;
  const r = await fetch(API + path, {
    ...opts,
    headers: {
      'Accept': 'application/json',
      ...(isForm ? {} : { 'Content-Type': 'application/json' }),
      ...(TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {}),
      ...(opts.headers || {}),
    },
  });
  if (!r.ok) {
    const e = await r.json().catch(() => ({}));
    const msg = e?.error?.message || e?.message
      || (e?.errors ? Object.values(e.errors).flat().join(' ') : '')
      || ('HTTP ' + r.status);
    const err = new Error(msg); err.status = r.status; throw err;
  }
  return r.status === 204 ? null : r.json();
}
async function apiBlob(path) {
  const r = await fetch(API + path, { headers: { Authorization: 'Bearer ' + TOKEN, 'Accept': '*/*' } });
  if (!r.ok) { const err = new Error('HTTP ' + r.status); err.status = r.status; throw err; }
  return r.blob();
}
const secH = (s) => { s = s || 0; const h = Math.floor(s / 3600), m = Math.round((s % 3600) / 60); return h ? h + 'h ' + m + 'm' : m + 'm'; };
const t = (iso) => iso ? new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—';
const dt = (iso) => iso ? new Date(iso).toLocaleString([], { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';
// esc() also escapes quotes so escaped values are safe inside HTML attributes (data-*).
const esc = (s) => (s == null ? '' : String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])));
const today = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }; // LOCAL date, not UTC — after midnight IST the console must default to the IST day
const fullName = (e) => ((e?.first_name || '') + ' ' + (e?.last_name || '')).trim();
const deniedCard = () => '<tr><td colspan="12"><div class="denied"><div class="big">🔒</div><b>Your role cannot view this</b><br>Ask a company admin to grant access.</div></td></tr>';
const isDenied = (e) => e && e.status === 403;

// ---- session ----
function enterApp() {
  $('#who').innerHTML = '<b>' + esc(ME.name) + '</b><br>' + esc(ME.role_name || ME.role || '');
  if (ME.company) $('#company-name').textContent = ME.company;
  $('#login').classList.add('hide'); $('#app').classList.remove('hide');
  show('dashboard');
  // Temp-password logins must set their own password before doing anything else.
  if (ME.must_change_password) openForcedPwd();
}
$('#btn-login').onclick = async () => {
  $('#login-err').textContent = '';
  try {
    const res = await api('/auth/login', { method: 'POST', body: JSON.stringify({ email: $('#email').value, password: $('#password').value }) });
    TOKEN = res.token; ME = res.user;
    sessionStorage.setItem('ept_token', TOKEN); // survive refresh
    enterApp();
  } catch (e) { $('#login-err').textContent = e.message; }
};
$('#password').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#btn-login').click(); });
$('#signout').onclick = async () => {
  try { await api('/auth/logout', { method: 'POST' }); } catch (e) { /* token may already be dead */ }
  TOKEN = null; ME = null; sessionStorage.removeItem('ept_token');
  clearInterval(poll); $('#app').classList.add('hide'); $('#login').classList.remove('hide');
};
// Restore session on refresh.
(async () => {
  const saved = sessionStorage.getItem('ept_token');
  if (!saved) return;
  TOKEN = saved;
  try { const res = await api('/auth/me'); ME = res.user; enterApp(); }
  catch (e) { TOKEN = null; sessionStorage.removeItem('ept_token'); }
})();

// ---- nav ----
const TITLES = {
  dashboard: ['Live Dashboard', 'Real-time workforce status'],
  attendance: ['Attendance', 'Daily sheet, regularization & holiday calendar'],
  screenshots: ['Screenshots', 'Policy-driven screen captures — every view is audit-logged'],
  usage: ['Usage & Compliance', 'Per-employee application and website time'],
  violations: ['Violations', 'Compliance events across the company'],
  employees: ['Employees', 'Directory & lifecycle'],
  users: ['Users', 'Login accounts, roles & credentials'],
  devices: ['Devices', 'Registered endpoints & agent health'],
  policies: ['Policies', 'The control room — what is tracked, for whom'],
  biometric: ['Biometric', 'Door punches, mapping & reconciliation'],
  reports: ['Reports & Exports', 'CSV exports for Excel and payroll'],
  license: ['Licence', 'Key, plan, device seats & daily validation'],
  ops: ['Audit & Ops', 'Who did what, storage growth & database backups'],
};
$$('.nav').forEach((n) => n.onclick = () => show(n.dataset.view));
function show(v) {
  $$('.nav').forEach((n) => n.classList.toggle('active', n.dataset.view === v));
  $$('.view').forEach((el) => el.classList.remove('active'));
  $('#v-' + v).classList.add('active');
  $('#page-title').textContent = TITLES[v][0]; $('#page-sub').textContent = TITLES[v][1];
  clearInterval(poll);
  if (v === 'dashboard') { loadDashboard(); poll = setInterval(loadDashboard, 15000); }
  if (v === 'attendance') initAttendance();
  if (v === 'screenshots') initScreenshots();
  if (v === 'usage') initUsage();
  if (v === 'violations') loadViolations();
  if (v === 'employees') loadEmployees();
  if (v === 'users') loadUsers();
  if (v === 'devices') loadDevices();
  if (v === 'policies') initPolicies();
  if (v === 'biometric') initBiometric();
  if (v === 'reports') initReports();
  if (v === 'license') loadLicense();
  if (v === 'ops') loadOps();
  CURRENT = v;
}

// ---- shared caches ----
let EMP_CACHE = null, ORG_CACHE = null, DEV_CACHE = null;
async function employeesList(force = false) {
  if (!EMP_CACHE || force) {
    const d = await api('/employees?per_page=500');
    EMP_CACHE = d.data || [];
  }
  return EMP_CACHE;
}
async function orgLists(force = false) {
  if (!ORG_CACHE || force) {
    const types = ['branches', 'departments', 'teams', 'designations', 'shifts'];
    ORG_CACHE = {};
    await Promise.all(types.map(async (ty) => {
      try { ORG_CACHE[ty] = (await api('/org/' + ty)).data || []; }
      catch (e) { ORG_CACHE[ty] = []; }
    }));
  }
  return ORG_CACHE;
}
async function devicesList(force = false) {
  if (!DEV_CACHE || force) {
    const d = await api('/devices?per_page=500');
    DEV_CACHE = d.data || [];
  }
  return DEV_CACHE;
}
function fillSelect(sel, rows, labelFn, valueFn, emptyLabel) {
  sel.innerHTML = (emptyLabel ? '<option value="">' + esc(emptyLabel) + '</option>' : '')
    + rows.map((r) => '<option value="' + esc(valueFn(r)) + '">' + esc(labelFn(r)) + '</option>').join('');
}
// Refill an employee picker, keeping the current selection when it still exists.
function fillEmpPicker(sel, emps) {
  const prev = sel.value;
  fillSelect(sel, emps, (e) => fullName(e) + ' (' + (e.employee_code || '#' + e.id) + ')', (e) => e.id, emps.length ? null : 'No employees yet');
  if (prev && [...sel.options].some((o) => o.value === prev)) sel.value = prev;
}

// ---- 1. dashboard ----
async function loadDashboard() {
  try {
    const d = await api('/dashboard/live-status');
    const c = d.cards;
    const cards = [
      ['Employees', c.total_employees], ['Active now', c.active_now], ['Idle', c.idle_now],
      ['On break', c.on_break], ['Offline', c.offline], ['Camera blocked', c.camera_blocked],
      ['Violations today', c.violations_today], ['Screenshots', c.screenshots_today],
    ];
    $('#kpis').innerHTML = cards.map(([l, v]) => '<div class="kpi"><div class="l">' + esc(l) + '</div><div class="v">' + (v ?? 0) + '</div></div>').join('');
    $('#live-rows').innerHTML = d.employees.map((e) => {
      const cls = { ONLINE: 't-ok', IDLE: 't-idle', AWAY: 't-warn', OFFLINE: 't-off' }[e.status] || 't-off';
      return '<tr class="clk" data-id="' + e.employee_id + '" data-name="' + esc(e.name) + '">'
        + '<td><span class="nm">' + esc(e.name) + '</span></td><td>' + esc(e.team || '—') + '</td>'
        + '<td><span class="tag ' + cls + '">' + esc(e.status) + '</span></td>'
        + '<td>' + secH(e.active_seconds) + '</td><td>' + secH(e.idle_seconds) + '</td><td>' + t(e.last_seen) + '</td></tr>';
    }).join('') || '<tr><td colspan="6" class="mut">No employees online yet.</td></tr>';
  } catch (e) {
    if (isDenied(e)) { $('#live-rows').innerHTML = deniedCard(); $('#kpis').innerHTML = ''; }
  }
  try {
    const h = await api('/dashboard/device-health');
    $('#dash-dev-rows').innerHTML = (h.data || []).map((v) => {
      const hc = { HEALTHY: 't-ok', DEGRADED: 't-warn', STOPPED: 't-danger' }[v.agent_health] || 't-off';
      const cc = { COMPLIANT: 't-ok', WARNING: 't-warn', NON_COMPLIANT: 't-danger', CRITICAL: 't-danger' }[v.compliance_status] || 't-off';
      return '<tr><td><b>' + esc(v.computer_name || v.device_uuid || '—') + '</b></td>'
        + '<td>' + esc(fullName(v.employee) || '—') + '</td><td>' + esc(v.app_version || '—') + '</td>'
        + '<td><span class="tag ' + hc + '">' + esc(v.agent_health || '—') + '</span></td>'
        + '<td><span class="tag ' + cc + '">' + esc(v.compliance_status || '—') + '</span></td>'
        + '<td>' + (v.sync_pending_count || 0) + '</td><td>' + dt(v.last_heartbeat_at) + '</td></tr>';
    }).join('') || '<tr><td colspan="7" class="mut">No devices registered — install the SmartEPT agent to see health here.</td></tr>';
  } catch (e) {
    if (isDenied(e)) $('#dash-dev-rows').innerHTML = deniedCard();
  }
}
$('#live-rows').addEventListener('click', (e) => {
  const tr = e.target.closest('tr[data-id]');
  if (tr) openEmployee(Number(tr.dataset.id), tr.dataset.name);
});

// ---- 2. screenshots ----
let SS_URLS = []; // object URLs to revoke between loads
let SS_META = {}; // id -> metadata for lightbox
let SS_SEQ = 0;   // guards against overlapping loads (e.g. evidence-link jump)
async function initScreenshots() {
  if (!$('#ss-date').value) $('#ss-date').value = today();
  try {
    const emps = await employeesList();
    fillEmpPicker($('#ss-emp'), emps);
    if ($('#ss-emp').value) loadScreenshots();
  } catch (e) {
    if (isDenied(e)) { $('#ss-grid').innerHTML = ''; showSsEmpty('Your role cannot view the employee list, so screenshots cannot be browsed.'); }
  }
}
function showSsEmpty(html) { const el = $('#ss-empty'); el.className = 'empty'; el.innerHTML = html; }
function clearSsEmpty() { const el = $('#ss-empty'); el.className = 'hide'; el.innerHTML = ''; }
async function loadScreenshots() {
  const empId = $('#ss-emp').value, date = $('#ss-date').value || today();
  if (!empId) return;
  const seq = ++SS_SEQ;
  SS_URLS.forEach((u) => URL.revokeObjectURL(u)); SS_URLS = []; SS_META = {};
  const grid = $('#ss-grid'); grid.innerHTML = '<div class="mut">Loading…</div>'; clearSsEmpty();
  const empName = $('#ss-emp').selectedOptions[0] ? $('#ss-emp').selectedOptions[0].textContent : '';
  $('#ss-title').textContent = 'Screenshot timeline — ' + empName + ' · ' + date;
  try {
    const d = await api('/reports/employee/' + empId + '/screenshots?date=' + encodeURIComponent(date));
    if (seq !== SS_SEQ) return; // a newer load superseded this one
    const shots = d.data || [];
    if (!shots.length) {
      grid.innerHTML = '';
      showSsEmpty('<b>No screenshots for this day.</b><br>Screenshots appear here once the desktop agent uploads them — capture must be enabled in the employee\'s effective screenshot policy, and the agent captures on interval, at random, or on violations per that policy.');
      return;
    }
    grid.innerHTML = shots.map((s) => {
      SS_META[s.id] = s;
      return '<div class="shotcard" data-shot="' + s.id + '">'
        + '<div class="img" id="ss-img-' + s.id + '">loading…</div>'
        + '<div class="m"><b>' + t(s.captured_at) + '</b>'
        + esc(s.active_app || s.window_title || '—')
        + ' · <span style="color:var(--ink-3)">' + esc(s.trigger_reason || '') + '</span></div></div>';
    }).join('');
    // Evidence jump: highlight the capture taken at (or nearest to) the
    // violation moment, so "View evidence" lands on the exact screenshot.
    if (window._EV_TIME) {
      const target = new Date(String(window._EV_TIME).replace(' ', 'T')).getTime();
      window._EV_TIME = null;
      if (!isNaN(target)) {
        let best = null, bestDiff = Infinity;
        shots.forEach((s) => {
          const t2 = new Date(String(s.captured_at).replace(' ', 'T')).getTime();
          const diff = Math.abs(t2 - target);
          if (diff < bestDiff) { bestDiff = diff; best = s; }
        });
        if (best && bestDiff <= 5 * 60 * 1000) {
          const el = document.querySelector('[data-shot="' + best.id + '"]');
          if (el) {
            el.classList.add('ev-hit');
            setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'center' }), 150);
          }
        }
      }
    }

    // Fetch each image as a blob with the bearer token (the file route is protected).
    shots.forEach(async (s) => {
      const slot = document.getElementById('ss-img-' + s.id);
      try {
        const blob = await apiBlob('/screenshots/' + s.id + '/file');
        const url = URL.createObjectURL(blob);
        if (seq !== SS_SEQ) { URL.revokeObjectURL(url); return; }
        SS_URLS.push(url);
        SS_META[s.id].objectUrl = url;
        if (slot) slot.innerHTML = '<img src="' + url + '" alt="Screenshot">';
      } catch (e) { if (slot && seq === SS_SEQ) slot.textContent = e.status === 403 ? 'no access' : 'file missing'; }
    });
  } catch (e) {
    if (seq !== SS_SEQ) return;
    grid.innerHTML = '';
    showSsEmpty(isDenied(e) ? '<b>Your role cannot view screenshots.</b><br>The screenshot.view permission is required.' : esc(e.message));
  }
}
$('#ss-load').onclick = loadScreenshots;
$('#ss-emp').addEventListener('change', loadScreenshots);
$('#ss-date').addEventListener('change', loadScreenshots);
$('#ss-grid').addEventListener('click', (e) => {
  const card = e.target.closest('[data-shot]');
  if (!card) return;
  const s = SS_META[card.dataset.shot];
  if (!s || !s.objectUrl) return;
  $('#shot-img').src = s.objectUrl;
  $('#shot-meta').textContent = [t(s.captured_at), s.active_app, s.window_title, s.trigger_reason].filter(Boolean).join(' · ');
  $('#shot-ovl').classList.add('open');
});
$('#shot-ovl').addEventListener('click', () => $('#shot-ovl').classList.remove('open'));

// ---- 3. usage & compliance ----
async function initUsage() {
  if (!$('#us-date').value) $('#us-date').value = today();
  try {
    const emps = await employeesList();
    fillEmpPicker($('#us-emp'), emps);
    if ($('#us-emp').value) loadUsage();
  } catch (e) {
    if (isDenied(e)) $('#us-app-rows').innerHTML = deniedCard();
  }
}
async function loadUsage() {
  const id = $('#us-emp').value, date = $('#us-date').value || today();
  if (!id) return;
  const q = '?date=' + encodeURIComponent(date);
  const secTable = (rows, keys, tbody, empty) => {
    tbody.innerHTML = (rows || []).map((r) => '<tr>'
      + '<td><b>' + esc(r[keys[0]] || '—') + '</b></td><td>' + esc(r.category || '—') + '</td>'
      + '<td>' + secH(Number(r.seconds)) + '</td>'
      + '<td><span class="tag ' + (r.status === 'VIOLATION' ? 't-danger' : 't-ok') + '">' + esc(r.status || 'OK') + '</span></td></tr>').join('')
      || '<tr><td colspan="4" class="mut">' + empty + '</td></tr>';
  };
  try {
    const a = await api('/reports/employee/' + id + '/app-usage' + q);
    secTable(a.data, ['app_name'], $('#us-app-rows'), 'No app usage recorded for this day.');
  } catch (e) { $('#us-app-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="4" class="mut">' + esc(e.message) + '</td></tr>'; }
  try {
    const w = await api('/reports/employee/' + id + '/website-usage' + q);
    secTable(w.data, ['site'], $('#us-web-rows'), 'No website usage recorded for this day.');
  } catch (e) { $('#us-web-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="4" class="mut">' + esc(e.message) + '</td></tr>'; }
  try {
    const c = await api('/reports/employee/' + id + '/compliance' + q);
    $('#us-comp-rows').innerHTML = (c.data || []).map((v) => {
      const sc = { LOW: 't-info', MEDIUM: 't-warn', HIGH: 't-danger', CRITICAL: 't-danger' }[v.severity] || 't-off';
      return '<tr><td>' + t(v.started_at) + '</td><td>' + esc(String(v.event_type || '').replace(/_/g, ' ')) + '</td>'
        + '<td><span class="tag ' + sc + '">' + esc(v.severity) + '</span></td>'
        + '<td>' + esc(v.detected_value || '—') + '</td><td>' + esc(v.action_taken || '—') + '</td></tr>';
    }).join('') || '<tr><td colspan="5" class="mut">No compliance events for this day.</td></tr>';
  } catch (e) { $('#us-comp-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="5" class="mut">' + esc(e.message) + '</td></tr>'; }
}
$('#us-load').onclick = loadUsage;
$('#us-emp').addEventListener('change', loadUsage);
$('#us-date').addEventListener('change', loadUsage);
$('#us-open-drawer').onclick = () => {
  const sel = $('#us-emp');
  if (sel.value) openEmployee(Number(sel.value), sel.selectedOptions[0].textContent.replace(/\s*\(.*\)$/, ''));
};

// ---- 4. violations ----
async function loadViolations() {
  try {
    const d = await api('/dashboard/violations?per_page=100');
    $('#viol-rows').innerHTML = (d.data || []).map((v) => {
      const sc = { LOW: 't-info', MEDIUM: 't-warn', HIGH: 't-danger', CRITICAL: 't-danger' }[v.severity] || 't-off';
      const date = v.started_at ? String(v.started_at).slice(0, 10) : today();
      const evidence = v.screenshot_captured
        ? '<a data-ev-emp="' + (v.employee?.id ?? '') + '" data-ev-name="' + esc(fullName(v.employee)) + '" data-ev-date="' + esc(date) + '" data-ev-time="' + esc(String(v.started_at || '')) + '" style="cursor:pointer;font-weight:600">View evidence</a>'
        : '<span class="mut">—</span>';
      return '<tr><td>' + dt(v.started_at) + '</td><td><span class="nm">' + esc(fullName(v.employee) || '—') + '</span></td>'
        + '<td>' + esc(v.event_category) + '</td><td>' + esc(String(v.event_type || '').replace(/_/g, ' ')) + '</td>'
        + '<td><span class="tag ' + sc + '">' + esc(v.severity) + '</span></td><td>' + esc(v.detected_value || '—') + '</td>'
        + '<td>' + esc(v.action_taken || '—') + '</td><td>' + evidence + '</td></tr>';
    }).join('') || '<tr><td colspan="8" class="mut">No violations recorded.</td></tr>';
  } catch (e) {
    $('#viol-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="8" class="mut">' + esc(e.message) + '</td></tr>';
  }
}
$('#viol-rows').addEventListener('click', async (e) => {
  const a = e.target.closest('[data-ev-emp]');
  if (!a || !a.dataset.evEmp) return;
  window._EV_TIME = a.dataset.evTime || null; // highlight the exact capture
  show('screenshots');
  await initScreenshots();
  $('#ss-emp').value = a.dataset.evEmp;
  $('#ss-date').value = a.dataset.evDate;
  loadScreenshots();
});

// ---- 5. employees ----
let EMP_EDIT_ID = null, EMP_DEV_COUNTS = null, EMP_SEARCH_TIMER = null;
async function loadEmployees() {
  const q = $('#emp-q').value.trim();
  try {
    const d = await api('/employees?per_page=200' + (q ? '&q=' + encodeURIComponent(q) : ''));
    const rows = d.data || [];
    if (!q) EMP_CACHE = rows; // refresh picker cache on unfiltered loads
    if (EMP_DEV_COUNTS === null) {
      EMP_DEV_COUNTS = {};
      try {
        (await devicesList()).forEach((dev) => {
          if (dev.employee_id) EMP_DEV_COUNTS[dev.employee_id] = (EMP_DEV_COUNTS[dev.employee_id] || 0) + 1;
        });
      } catch (e) { /* devices list may be role-gated; counts stay 0 */ }
    }
    $('#emp-rows').innerHTML = rows.map((e) => {
      const st = { ACTIVE: 't-ok', ON_LEAVE: 't-warn', RELIEVED: 't-off' }[e.employment_status] || 't-off';
      return '<tr class="clk" data-id="' + e.id + '" data-name="' + esc(fullName(e)) + '">'
        + '<td>' + esc(e.employee_code) + '</td>'
        + '<td><span class="nm">' + esc(fullName(e)) + '</span></td>'
        + '<td>' + esc(e.email || '—') + '</td>'
        + '<td>' + esc(e.department?.name || '—') + '</td><td>' + esc(e.team?.name || '—') + '</td>'
        + '<td>' + esc(e.shift?.name || '—') + '</td>'
        + '<td><span class="tag ' + st + '">' + esc(e.employment_status || '—') + '</span></td>'
        + '<td>' + (EMP_DEV_COUNTS[e.id] || 0) + '</td>'
        + '<td class="row" style="flex-wrap:nowrap">'
        + '<button class="btn" data-act="edit">Edit</button>'
        + (e.employment_status !== 'RELIEVED' ? '<button class="btn danger" data-act="relieve">Relieve</button>' : '')
        + '<button class="btn danger" data-act="del">Delete</button></td></tr>';
    }).join('') || '<tr><td colspan="9" class="mut">No employees' + (q ? ' matching "' + esc(q) + '"' : '') + '.</td></tr>';
  } catch (e) {
    $('#emp-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="9" class="mut">' + esc(e.message) + '</td></tr>';
  }
}
$('#emp-q').addEventListener('input', () => {
  clearTimeout(EMP_SEARCH_TIMER);
  EMP_SEARCH_TIMER = setTimeout(loadEmployees, 300);
});
$('#emp-rows').addEventListener('click', async (e) => {
  const tr = e.target.closest('tr[data-id]');
  if (!tr) return;
  const id = Number(tr.dataset.id);
  const act = e.target.closest('[data-act]');
  if (act && act.dataset.act === 'edit') { openEmpModal(id); return; }
  if (act && act.dataset.act === 'relieve') {
    const reason = prompt('Relieve ' + tr.dataset.name + '?\n\nThis disables their login, stops the monitoring agent on all their devices and frees the licence seats.\n\nEnter the reason (required, kept in the audit log):');
    if (reason === null) return;
    if (!reason.trim()) { alert('A reason is required.'); return; }
    try {
      await api('/employees/' + id + '/relieve', { method: 'POST', body: JSON.stringify({ reason: reason.trim() }) });
      EMP_CACHE = null; DEV_CACHE = null;
      loadEmployees();
    } catch (err) { alert(err.message); }
    return;
  }
  if (act && act.dataset.act === 'del') {
    if (!confirm('Delete ' + tr.dataset.name + '? This removes the employee record (activity history is retained per policy).')) return;
    try {
      await api('/employees/' + id, { method: 'DELETE' });
      EMP_CACHE = null; EMP_DEV_COUNTS = null;
      loadEmployees();
    } catch (err) { alert(err.message); }
    return;
  }
  openEmployee(id, tr.dataset.name);
});
async function openEmpModal(id) {
  EMP_EDIT_ID = id || null;
  $('#emp-m-title').textContent = id ? 'Edit employee' : 'Add employee';
  $('#emp-m-err').textContent = '';
  const org = await orgLists();
  fillSelect($('#f-branch'), org.branches, (r) => r.name, (r) => r.id, '— none —');
  fillSelect($('#f-dept'), org.departments, (r) => r.name, (r) => r.id, '— none —');
  fillSelect($('#f-team'), org.teams, (r) => r.name, (r) => r.id, '— none —');
  fillSelect($('#f-desig'), org.designations, (r) => r.name, (r) => r.id, '— none —');
  fillSelect($('#f-shift'), org.shifts, (r) => r.name + (r.start_time ? ' (' + String(r.start_time).slice(0, 5) + '–' + String(r.end_time || '').slice(0, 5) + ')' : ''), (r) => r.id, '— none —');
  const set = (sel, v) => { $(sel).value = v ?? ''; };
  if (id) {
    try {
      const d = await api('/employees/' + id);
      const e = d.data;
      set('#f-first', e.first_name); set('#f-last', e.last_name); set('#f-code', e.employee_code);
      set('#f-email', e.email); set('#f-mobile', e.mobile); set('#f-status', e.employment_status || 'ACTIVE');
      set('#f-branch', e.branch_id); set('#f-dept', e.department_id); set('#f-team', e.team_id);
      set('#f-desig', e.designation_id); set('#f-shift', e.shift_id);
      set('#f-doj', e.date_of_joining ? String(e.date_of_joining).slice(0, 10) : '');
      set('#f-bio', e.biometric_id);
    } catch (err) { $('#emp-m-err').textContent = err.message; }
  } else {
    ['#f-first', '#f-last', '#f-code', '#f-email', '#f-mobile', '#f-doj', '#f-bio'].forEach((s) => set(s, ''));
    set('#f-status', 'ACTIVE');
    ['#f-branch', '#f-dept', '#f-team', '#f-desig', '#f-shift'].forEach((s) => set(s, ''));
  }
  $('#emp-ovl').classList.add('open');
}
$('#emp-add').onclick = () => openEmpModal(null);

// ---- bulk import (17-Jul) ----
const EMP_CSV_HEADER = 'employee_code,first_name,last_name,email,mobile,department,team,branch,designation,shift,date_of_joining,biometric_id';
$('#emp-template').onclick = () => {
  const sample = EMP_CSV_HEADER + '\n'
    + 'E-2001,Rahul,Sharma,rahul.sharma@company.com,9848012345,Operations,Team A,Head Office,Executive,General Shift,2026-07-01,\n'
    + 'E-2002,Sneha,Iyer,sneha.iyer@company.com,9848067890,Sales,Team B,Head Office,Manager,General Shift,2026-07-01,BIO-114';
  const blob = new Blob([sample], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = 'smartept-employees-template.csv';
  a.click(); URL.revokeObjectURL(a.href);
};
$('#emp-import').onclick = () => {
  $('#import-file').value = ''; $('#import-result').innerHTML = ''; $('#import-run').disabled = true;
  $('#import-ovl').classList.add('open');
};
$('#import-x').onclick = () => $('#import-ovl').classList.remove('open');
function importForm(dry) {
  const f = $('#import-file').files[0];
  if (!f) { $('#import-result').innerHTML = '<span style="color:var(--danger)">Choose a CSV file first.</span>'; return null; }
  const fd = new FormData();
  fd.append('file', f);
  fd.append('dry_run', dry ? '1' : '0');
  fd.append('create_login', $('#import-login').checked ? '1' : '0');
  return fd;
}
async function runImport(dry) {
  const fd = importForm(dry); if (!fd) return;
  $('#import-result').innerHTML = '<span class="mut">' + (dry ? 'Checking…' : 'Importing…') + '</span>';
  try {
    const r = await api('/employees/bulk-import', { method: 'POST', body: fd });
    const su = r.summary || {};
    const bad = (r.results || []).filter((x) => !x.ok);
    let html = '<div class="' + (bad.length ? 'never' : '') + '" style="' + (bad.length ? '' : 'background:var(--ok-w);border:1px solid #B6E5CE;border-radius:10px;padding:12px') + '">'
      + '<b style="color:' + (bad.length ? 'var(--danger)' : 'var(--ok)') + '">'
      + (dry ? 'Preview: ' : '✓ Imported: ') + (su.created || 0) + (dry ? ' rows ready' : ' created')
      + (su.failed ? ' · ' + su.failed + ' with problems' : '') + '</b>';
    if (bad.length) {
      html += '<div style="max-height:180px;overflow:auto;margin-top:8px;font-size:11.5px">'
        + bad.map((x) => 'Line ' + x.line + ' (' + esc(x.code || '—') + '): ' + esc(x.error)).join('<br>') + '</div>';
    }
    if (!dry && (r.credentials || []).length) {
      html += '<div style="margin-top:10px;font-size:11.5px"><b>Temp passwords (shown once — hand these out):</b><br>'
        + r.credentials.map((c) => esc(c.email) + ' → <code>' + esc(c.temp_password) + '</code>').join('<br>') + '</div>';
    }
    html += '</div>';
    $('#import-result').innerHTML = html;
    $('#import-run').disabled = dry ? false : true;
    if (!dry) { loadEmployees(); }
  } catch (e) { $('#import-result').innerHTML = '<span style="color:var(--danger)">' + esc(e.message) + '</span>'; }
}
$('#import-preview').onclick = () => runImport(true);
$('#import-run').onclick = () => runImport(false);
$('#import-file').onchange = () => { $('#import-run').disabled = true; $('#import-result').innerHTML = ''; };
$('#emp-m-save').onclick = async () => {
  $('#emp-m-err').textContent = '';
  const numOrNull = (s) => $(s).value ? Number($(s).value) : null;
  const body = {
    first_name: $('#f-first').value.trim(),
    last_name: $('#f-last').value.trim() || null,
    employee_code: $('#f-code').value.trim(),
    email: $('#f-email').value.trim() || null,
    mobile: $('#f-mobile').value.trim() || null,
    employment_status: $('#f-status').value,
    branch_id: numOrNull('#f-branch'),
    department_id: numOrNull('#f-dept'),
    team_id: numOrNull('#f-team'),
    designation_id: numOrNull('#f-desig'),
    shift_id: numOrNull('#f-shift'),
    date_of_joining: $('#f-doj').value || null,
    biometric_id: $('#f-bio').value.trim() || null,
  };
  try {
    if (EMP_EDIT_ID) {
      await api('/employees/' + EMP_EDIT_ID, { method: 'PUT', body: JSON.stringify(body) });
    } else {
      const r = await api('/employees', { method: 'POST', body: JSON.stringify(body) });
      // A self-service login may have been auto-created — surface its one-time password.
      if (r && r.temp_password) showCredentials((r.login && r.login.email) || body.email, r.temp_password);
    }
    $('#emp-ovl').classList.remove('open');
    EMP_CACHE = null;
    loadEmployees();
  } catch (err) { $('#emp-m-err').textContent = err.message; }
};

// ---- 6. devices ----
async function loadDevices() {
  try {
    const [list, health] = await Promise.all([
      devicesList(true),
      api('/dashboard/device-health').then((r) => r.data || []).catch(() => []),
    ]);
    const hByUuid = {};
    health.forEach((h) => { hByUuid[h.device_uuid] = h; });
    $('#dev-rows').innerHTML = list.map((v) => {
      const h = hByUuid[v.device_uuid] || v; // merge freshest health snapshot
      const hc = { HEALTHY: 't-ok', DEGRADED: 't-warn', STOPPED: 't-danger' }[h.agent_health] || 't-off';
      const cc = { COMPLIANT: 't-ok', WARNING: 't-warn', NON_COMPLIANT: 't-danger', CRITICAL: 't-danger' }[h.compliance_status] || 't-off';
      const sc = { ONLINE: 't-ok', IDLE: 't-idle', AWAY: 't-warn', OFFLINE: 't-off' }[h.current_status] || 't-off';
      return '<tr data-devid="' + v.id + '" data-devname="' + esc(v.computer_name || v.device_uuid) + '"><td><b>' + esc(v.computer_name || v.device_uuid) + '</b></td>'
        + '<td>' + esc(fullName(v.employee) || '—') + '</td>'
        + '<td>' + esc(v.os_version || '—') + '</td><td>' + esc(h.app_version || v.app_version || '—') + '</td>'
        + '<td><span class="tag ' + hc + '">' + esc(h.agent_health || '—') + '</span></td>'
        + '<td><span class="tag ' + cc + '">' + esc(h.compliance_status || '—') + '</span></td>'
        + '<td>' + (v.unbound_at ? '<span class="tag t-danger">UNBOUND</span>' : '<span class="tag ' + sc + '">' + esc(h.current_status || '—') + '</span>') + '</td>'
        + '<td>' + (h.sync_pending_count || 0) + '</td><td>' + dt(h.last_heartbeat_at) + '</td>'
        + '<td>' + (v.unbound_at
            ? '<button class="btn" data-devact="rebind">Approve re-bind</button>'
            : '<button class="btn danger" data-devact="unbind">Unbind</button>') + '</td></tr>';
    }).join('') || '<tr><td colspan="10" class="mut">No devices registered. Devices appear when the SmartEPT desktop agent registers on an employee\'s PC.</td></tr>';
  } catch (e) {
    $('#dev-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="10" class="mut">' + esc(e.message) + '</td></tr>';
  }
}
$('#dev-rows').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-devact]');
  if (!btn) return;
  const tr = e.target.closest('tr[data-devid]');
  const id = Number(tr.dataset.devid);
  if (btn.dataset.devact === 'unbind') {
    if (!confirm('Unbind ' + tr.dataset.devname + '?\n\nThe agent on this PC stops immediately, its licence seat is freed, and it cannot re-register until you approve a re-bind.')) return;
    try { await api('/devices/' + id + '/unbind', { method: 'POST' }); DEV_CACHE = null; loadDevices(); }
    catch (err) { alert(err.message); }
  }
  if (btn.dataset.devact === 'rebind') {
    try { await api('/devices/' + id + '/rebind', { method: 'POST' }); DEV_CACHE = null; loadDevices(); }
    catch (err) { alert(err.message); }
  }
});

// ---- 7. policies ----
const POLICY_TYPES = [
  ['monitoring', 'Monitoring (master)'], ['screenshot', 'Screenshot'], ['webcam', 'Webcam presence'],
  ['application', 'Application'], ['website', 'Website'], ['network', 'Network'],
  ['device', 'Device compliance'], ['usb', 'USB'], ['vpn_proxy', 'VPN / Proxy'],
  ['break', 'Break'], ['attendance', 'Attendance'], ['compliance', 'Compliance scoring'],
];
// Field schemas mirror the policy table columns (see policy migrations).
// t: text | bool | num | dec | time | select | list (comma-separated → JSON array) | json (raw JSON object)
const POLICY_FIELDS = {
  monitoring: [
    { k: 'name', l: 'Policy name', t: 'text', full: 1 },
    { k: 'description', l: 'Description', t: 'text', full: 1 },
    { k: 'tracking_enabled', l: 'Tracking enabled', t: 'bool' },
    { k: 'working_hours_only', l: 'Track working hours only', t: 'bool' },
    { k: 'working_start', l: 'Working start', t: 'time' },
    { k: 'working_end', l: 'Working end', t: 'time' },
    { k: 'tracking_interval_seconds', l: 'Tracking interval (sec)', t: 'num' },
    { k: 'idle_threshold_seconds', l: 'Idle threshold (sec)', t: 'num' },
    { k: 'away_threshold_seconds', l: 'Away threshold (sec)', t: 'num' },
    { k: 'data_retention_days', l: 'Data retention (days)', t: 'num' },
    { k: 'app_usage_enabled', l: 'App usage tracking', t: 'bool' },
    { k: 'website_usage_enabled', l: 'Website usage tracking', t: 'bool' },
    { k: 'network_compliance_enabled', l: 'Network compliance', t: 'bool' },
    { k: 'usb_tracking_enabled', l: 'USB tracking', t: 'bool' },
    { k: 'vpn_proxy_detection_enabled', l: 'VPN/proxy detection', t: 'bool' },
    { k: 'remote_access_detection_enabled', l: 'Remote-access detection', t: 'bool' },
    { k: 'employee_status_visible', l: 'Employee sees own status', t: 'bool' },
    { k: 'consent_required', l: 'Consent required', t: 'bool' },
    { k: 'is_active', l: 'Active', t: 'bool' },
  ],
  screenshot: [
    { k: 'name', l: 'Policy name', t: 'text', full: 1 },
    { k: 'enabled', l: 'Screenshots enabled', t: 'bool' },
    { k: 'interval_enabled', l: 'Timed captures (OFF = violations only)', t: 'bool' },
    { k: 'interval_seconds', l: 'Interval (sec)', t: 'num' },
    { k: 'random_enabled', l: 'Random captures', t: 'bool' },
    { k: 'on_violation', l: 'Capture on violation', t: 'bool' },
    { k: 'on_blocked_website', l: 'On blocked website', t: 'bool' },
    { k: 'on_blocked_app', l: 'On blocked app', t: 'bool' },
    { k: 'during_idle', l: 'Capture during idle', t: 'bool' },
    { k: 'active_work_only', l: 'Active work only', t: 'bool' },
    { k: 'blur_sensitive', l: 'Blur sensitive areas', t: 'bool' },
    { k: 'retention_days', l: 'Retention (days)', t: 'num' },
    { k: 'excluded_apps', l: 'Excluded apps (comma-separated)', t: 'list', full: 1 },
    { k: 'excluded_websites', l: 'Excluded websites (comma-separated)', t: 'list', full: 1 },
  ],
  webcam: [
    { k: 'name', l: 'Policy name', t: 'text', full: 1 },
    { k: 'presence_enabled', l: 'Presence detection (yes/no signal)', t: 'bool' },
    { k: 'photo_enabled', l: 'Presence photos', t: 'bool' },
    { k: 'photo_interval_seconds', l: 'Photo interval (sec)', t: 'num' },
    { k: 'photo_on_violation', l: 'Photo on violation', t: 'bool' },
    { k: 'photo_on_attendance', l: 'Photo on attendance', t: 'bool' },
    { k: 'face_confidence_threshold', l: 'Face confidence (0–1)', t: 'dec' },
    { k: 'away_threshold_seconds', l: 'Away threshold (sec)', t: 'num' },
    { k: 'camera_blocked_threshold_seconds', l: 'Camera-blocked threshold (sec)', t: 'num' },
    { k: 'multiple_face_threshold_seconds', l: 'Multiple-face threshold (sec)', t: 'num' },
    { k: 'photo_retention_days', l: 'Photo retention (days)', t: 'num' },
  ],
  application: [
    { k: 'name', l: 'Policy name', t: 'text', full: 1 },
    { k: 'allowed_apps', l: 'Allowed apps (comma-separated)', t: 'list', full: 1 },
    { k: 'blocked_apps', l: 'Blocked apps (comma-separated)', t: 'list', full: 1 },
    { k: 'categories', l: 'Categories (JSON: {"excel.exe":"PRODUCTIVE"})', t: 'json', full: 1 },
    { k: 'action_on_blocked', l: 'Action on blocked', t: 'select', opts: ['LOG', 'WARN', 'NOTIFY', 'SCREENSHOT', 'CLOSE'] },
  ],
  website: [
    { k: 'name', l: 'Policy name', t: 'text', full: 1 },
    { k: 'allowed_sites', l: 'Allowed sites (comma-separated)', t: 'list', full: 1 },
    { k: 'blocked_sites', l: 'Blocked sites (comma-separated)', t: 'list', full: 1 },
    { k: 'categories', l: 'Categories (JSON: {"youtube":"NON_PRODUCTIVE"})', t: 'json', full: 1 },
    { k: 'track_full_url', l: 'Track full URL', t: 'bool' },
    { k: 'action_on_blocked', l: 'Action on blocked', t: 'select', opts: ['LOG', 'WARN', 'NOTIFY', 'SCREENSHOT', 'BLOCK'] },
  ],
  network: [
    { k: 'name', l: 'Policy name', t: 'text', full: 1 },
    { k: 'allowed_public_ips', l: 'Allowed public IPs (comma-separated)', t: 'list', full: 1 },
    { k: 'allowed_lan_ranges', l: 'Allowed LAN ranges (comma-separated)', t: 'list', full: 1 },
    { k: 'allowed_ssids', l: 'Allowed Wi-Fi SSIDs (comma-separated)', t: 'list', full: 1 },
    { k: 'allowed_vpn_networks', l: 'Allowed VPN networks (comma-separated)', t: 'list', full: 1 },
    { k: 'remote_work_allowed', l: 'Remote work allowed', t: 'bool' },
    { k: 'block_unknown_network', l: 'Block unknown network', t: 'bool' },
    { k: 'action_on_unauthorized', l: 'Action on unauthorized', t: 'select', opts: ['LOG', 'WARN', 'NOTIFY', 'BLOCK_LOGIN', 'REQUIRE_APPROVAL'] },
  ],
  device: [
    { k: 'name', l: 'Policy name', t: 'text', full: 1 },
    { k: 'require_antivirus', l: 'Require antivirus', t: 'bool' },
    { k: 'require_firewall', l: 'Require firewall', t: 'bool' },
    { k: 'require_disk_encryption', l: 'Require disk encryption', t: 'bool' },
    { k: 'min_os_version', l: 'Minimum OS version', t: 'text' },
    { k: 'blocked_software', l: 'Blocked software (comma-separated)', t: 'list', full: 1 },
    { k: 'settings', l: 'Extra settings (JSON object)', t: 'json', full: 1 },
  ],
  usb: [
    { k: 'name', l: 'Policy name', t: 'text', full: 1 },
    { k: 'action', l: 'Action on USB insert', t: 'select', opts: ['LOG', 'ALERT', 'VIOLATION', 'SCREENSHOT', 'REQUIRE_APPROVAL', 'BLOCK_STORAGE'] },
    { k: 'allowed_device_classes', l: 'Allowed device classes (comma-separated)', t: 'list', full: 1 },
  ],
  vpn_proxy: [
    { k: 'name', l: 'Policy name', t: 'text', full: 1 },
    { k: 'approved_tools', l: 'Approved tools (comma-separated)', t: 'list', full: 1 },
    { k: 'blocked_tools', l: 'Blocked tools (comma-separated)', t: 'list', full: 1 },
    { k: 'action_on_unauthorized', l: 'Action on unauthorized', t: 'select', opts: ['ALERT', 'VIOLATION', 'SCREENSHOT'] },
  ],
  break: [
    { k: 'name', l: 'Policy name', t: 'text', full: 1 },
    { k: 'break_types', l: 'Break types (comma-separated, e.g. TEA, LUNCH)', t: 'list', full: 1 },
    { k: 'auto_detect_from_idle', l: 'Auto-detect from idle', t: 'bool' },
    { k: 'requires_approval', l: 'Requires approval', t: 'bool' },
  ],
  attendance: [
    { k: 'name', l: 'Policy name', t: 'text', full: 1 },
    { k: 'late_grace_minutes', l: 'Late grace (min)', t: 'num' },
    { k: 'early_logout_grace_minutes', l: 'Early-logout grace (min)', t: 'num' },
    { k: 'min_working_hours', l: 'Minimum working hours', t: 'num' },
    { k: 'attendance_sources', l: 'Sources (comma-separated, e.g. AGENT, BIOMETRIC)', t: 'list', full: 1 },
    { k: 'settings', l: 'Extra settings (JSON object)', t: 'json', full: 1 },
  ],
  compliance: [
    { k: 'name', l: 'Policy name', t: 'text', full: 1 },
    { k: 'description', l: 'Description', t: 'text', full: 1 },
    { k: 'settings', l: 'Rules (JSON: per-violation severity, action, score penalty)', t: 'json', full: 1 },
    { k: 'is_active', l: 'Active', t: 'bool' },
  ],
};
let POL_LIST = [], POL_EDIT_ID = null;

function initPolicies() {
  const sel = $('#pol-type');
  if (sel.options.length === 0) {
    fillSelect(sel, POLICY_TYPES, (p) => p[1], (p) => p[0]);
    sel.addEventListener('change', () => { POL_EDIT_ID = null; loadPolicies(); });
  }
  loadPolicies();
  initAssignPanel();
}
async function loadPolicies() {
  const type = $('#pol-type').value;
  renderPolicyForm(type, null);
  try {
    const d = await api('/policies/' + type);
    POL_LIST = d.data || [];
    $('#pol-rows').innerHTML = POL_LIST.map((p) => '<tr>'
      + '<td><b>' + esc(p.name) + '</b></td><td><span class="tag t-info">v' + (p.version ?? 1) + '</span></td>'
      + '<td>' + dt(p.updated_at) + '</td>'
      + '<td class="row" style="flex-wrap:nowrap"><button class="btn" data-pol-edit="' + p.id + '">Edit</button>'
      + '<button class="btn danger" data-pol-del="' + p.id + '">Delete</button></td></tr>').join('')
      || '<tr><td colspan="4" class="mut">No ' + esc(type.replace('_', '/')) + ' policies yet — create the first one on the right.</td></tr>';
  } catch (e) {
    POL_LIST = [];
    $('#pol-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="4" class="mut">' + esc(e.message) + '</td></tr>';
  }
  refreshAssignPolicyOptions();
}
function renderPolicyForm(type, policy) {
  POL_EDIT_ID = policy ? policy.id : null;
  const label = (POLICY_TYPES.find((p) => p[0] === type) || [type, type])[1];
  $('#pol-form-title').textContent = (policy ? 'Edit "' + policy.name + '" (v' + (policy.version ?? 1) + ' → v' + ((policy.version ?? 1) + 1) + ' on save)' : 'Create ' + label + ' policy');
  $('#pol-err').textContent = '';
  $('#pol-form').innerHTML = (POLICY_FIELDS[type] || []).map((f, i) => {
    const v = policy ? policy[f.k] : undefined;
    const wrap = (inner) => '<div' + (f.full ? ' class="full"' : '') + '>' + inner + '</div>';
    const id = 'pf-' + f.k;
    if (f.t === 'bool') {
      return wrap('<div class="fbool"><input type="checkbox" id="' + id + '"' + (v ? ' checked' : '') + '><label for="' + id + '" style="margin:0;cursor:pointer">' + esc(f.l) + '</label></div>');
    }
    if (f.t === 'select') {
      return wrap('<label>' + esc(f.l) + '</label><select id="' + id + '">'
        + f.opts.map((o) => '<option' + (v === o ? ' selected' : '') + '>' + esc(o) + '</option>').join('') + '</select>');
    }
    if (f.t === 'list') {
      const val = Array.isArray(v) ? v.join(', ') : '';
      return wrap('<label>' + esc(f.l) + '</label><input id="' + id + '" value="' + esc(val) + '">');
    }
    if (f.t === 'json') {
      const val = (v && typeof v === 'object') ? JSON.stringify(v, null, 1) : (typeof v === 'string' ? v : '');
      return wrap('<label>' + esc(f.l) + '</label><textarea id="' + id + '">' + esc(val) + '</textarea>');
    }
    const typeAttr = f.t === 'num' ? 'number' : f.t === 'dec' ? 'number" step="0.05' : f.t === 'time' ? 'time' : 'text';
    const val = v == null ? '' : (f.t === 'time' ? String(v).slice(0, 5) : String(v));
    return wrap('<label>' + esc(f.l) + '</label><input type="' + typeAttr + '" id="' + id + '" value="' + esc(val) + '">');
  }).join('');
}
function collectPolicyForm(type) {
  const body = {};
  for (const f of POLICY_FIELDS[type] || []) {
    const el = document.getElementById('pf-' + f.k);
    if (!el) continue;
    if (f.t === 'bool') { body[f.k] = el.checked; continue; }
    const raw = el.value.trim();
    if (f.t === 'num') { if (raw !== '') body[f.k] = Number(raw); continue; }
    if (f.t === 'dec') { if (raw !== '') body[f.k] = parseFloat(raw); continue; }
    if (f.t === 'time') { if (raw !== '') body[f.k] = raw.length === 5 ? raw + ':00' : raw; continue; }
    if (f.t === 'list') { body[f.k] = raw ? raw.split(',').map((s) => s.trim()).filter(Boolean) : []; continue; }
    if (f.t === 'json') {
      if (!raw) { body[f.k] = null; continue; }
      try { body[f.k] = JSON.parse(raw); }
      catch (e) { throw new Error('"' + f.l + '" is not valid JSON.'); }
      continue;
    }
    body[f.k] = raw || null;
  }
  return body;
}
$('#pol-save').onclick = async () => {
  const type = $('#pol-type').value;
  $('#pol-err').textContent = '';
  let body;
  try { body = collectPolicyForm(type); } catch (e) { $('#pol-err').textContent = e.message; return; }
  if (!body.name) { $('#pol-err').textContent = 'Policy name is required.'; return; }
  try {
    if (POL_EDIT_ID) await api('/policies/' + type + '/' + POL_EDIT_ID, { method: 'PUT', body: JSON.stringify(body) });
    else await api('/policies/' + type, { method: 'POST', body: JSON.stringify(body) });
    loadPolicies();
  } catch (e) { $('#pol-err').textContent = e.message; }
};
$('#pol-cancel').onclick = () => renderPolicyForm($('#pol-type').value, null);
$('#pol-new').onclick = () => renderPolicyForm($('#pol-type').value, null);
$('#pol-rows').addEventListener('click', async (e) => {
  const edit = e.target.closest('[data-pol-edit]');
  if (edit) {
    const p = POL_LIST.find((x) => x.id === Number(edit.dataset.polEdit));
    if (p) renderPolicyForm($('#pol-type').value, p);
    return;
  }
  const del = e.target.closest('[data-pol-del]');
  if (del) {
    const p = POL_LIST.find((x) => x.id === Number(del.dataset.polDel));
    if (!p || !confirm('Delete policy "' + p.name + '"? Assignments pointing to it stop applying.')) return;
    try { await api('/policies/' + $('#pol-type').value + '/' + p.id, { method: 'DELETE' }); loadPolicies(); }
    catch (err) { alert(err.message); }
  }
});
// Assignments panel
function refreshAssignPolicyOptions() {
  fillSelect($('#as-policy'), POL_LIST, (p) => p.name + ' (v' + (p.version ?? 1) + ')', (p) => p.id, POL_LIST.length ? null : 'No policies of this type yet');
}
async function initAssignPanel() {
  await refreshAssignTargets();
}
async function refreshAssignTargets() {
  const kind = $('#as-type').value;
  const sel = $('#as-target');
  try {
    if (kind === 'COMPANY') {
      fillSelect(sel, [{ id: ME.company_id, name: ME.company || 'This company' }], (r) => r.name, (r) => r.id);
    } else if (kind === 'BRANCH' || kind === 'DEPARTMENT' || kind === 'TEAM') {
      const org = await orgLists();
      const rows = { BRANCH: org.branches, DEPARTMENT: org.departments, TEAM: org.teams }[kind] || [];
      fillSelect(sel, rows, (r) => r.name, (r) => r.id, rows.length ? null : 'None defined yet');
    } else if (kind === 'EMPLOYEE') {
      const emps = await employeesList();
      fillSelect(sel, emps, (e) => fullName(e) + ' (' + (e.employee_code || '#' + e.id) + ')', (e) => e.id, emps.length ? null : 'No employees yet');
    } else if (kind === 'DEVICE') {
      const devs = await devicesList();
      fillSelect(sel, devs, (d) => (d.computer_name || d.device_uuid) + ' — ' + (fullName(d.employee) || 'unassigned'), (d) => d.id, devs.length ? null : 'No devices yet');
    }
  } catch (e) {
    fillSelect(sel, [], (x) => x, (x) => x, isDenied(e) ? 'Your role cannot list these' : e.message);
  }
}
$('#as-type').addEventListener('change', refreshAssignTargets);
$('#as-save').onclick = async () => {
  const policyId = $('#as-policy').value, targetId = $('#as-target').value;
  if (!policyId || !targetId) { $('#as-log').textContent = 'Pick a policy and a target first.'; return; }
  const body = {
    policy_type: $('#pol-type').value.toUpperCase(), // e.g. vpn_proxy → VPN_PROXY
    policy_id: Number(policyId),
    assignable_type: $('#as-type').value,
    assignable_id: Number(targetId),
  };
  if ($('#as-from').value) body.effective_from = $('#as-from').value;
  if ($('#as-to').value) body.effective_to = $('#as-to').value;
  try {
    await api('/policies/assign', { method: 'POST', body: JSON.stringify(body) });
    $('#as-log').textContent = '✓ Assigned "' + $('#as-policy').selectedOptions[0].textContent + '" to '
      + $('#as-type').value + ': ' + $('#as-target').selectedOptions[0].textContent + '. Agents apply it on next heartbeat (~30s).';
  } catch (e) { $('#as-log').textContent = '✕ ' + e.message; }
};

// ---- 8. biometric ----
function initBiometric() {
  if (!$('#bio-date').value) $('#bio-date').value = today();
  loadBioDevices();
  loadBiometric();
  employeesList().then((emps) => fillEmpPicker($('#bio-map-emp'), emps)).catch(() => {});
}
let bdEditId = null;
let bdDevices = [];
async function loadBioDevices() {
  try {
    const d = await api('/integrations/biometric/devices');
    bdDevices = d.data || [];
    $('#biodev-rows').innerHTML = bdDevices.map((v) => '<tr>'
      + '<td><span class="nm">' + esc(v.name) + '</span></td>'
      + '<td>' + esc(v.device_serial || '—') + '</td>'
      + '<td>' + esc(v.location || '—') + '</td>'
      + '<td>' + esc(v.ip_address || '—') + '</td>'
      + '<td>' + esc(v.integration_method || '—') + '</td>'
      + '<td>' + esc(v.vendor || '—') + '</td>'
      + '<td><span class="tag ' + (v.status === 'ACTIVE' ? 't-ok' : 't-off') + '">' + esc(v.status) + '</span></td>'
      + '<td>' + (v.last_sync_at ? dt(v.last_sync_at) : '—') + '</td>'
      + '<td>' + (v.logs_count ?? 0) + '</td>'
      + '<td><button class="btn" data-bd-edit="' + v.id + '">Edit</button> <button class="btn" data-bd-del="' + v.id + '">Delete</button></td></tr>').join('')
      || '<tr><td colspan="10" class="mut">No punch devices registered yet — add your first one below. Punches can also arrive without a registered device (middleware push / CSV).</td></tr>';
  } catch (e) {
    $('#biodev-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="10" class="mut">' + esc(e.message) + '</td></tr>';
  }
}
function bdReset() {
  bdEditId = null;
  ['#bd-name', '#bd-serial', '#bd-loc', '#bd-ip', '#bd-vendor'].forEach((q) => { $(q).value = ''; });
  $('#bd-method').value = 'MIDDLEWARE_PUSH';
  $('#bd-status').value = 'ACTIVE';
  $('#bd-save').textContent = 'Add device';
  $('#bd-msg').textContent = '';
}
$('#bd-reset').onclick = bdReset;
$('#bd-save').onclick = async () => {
  const body = {
    name: $('#bd-name').value.trim(),
    device_serial: $('#bd-serial').value.trim() || null,
    location: $('#bd-loc').value.trim() || null,
    ip_address: $('#bd-ip').value.trim() || null,
    integration_method: $('#bd-method').value,
    vendor: $('#bd-vendor').value.trim() || null,
    status: $('#bd-status').value,
  };
  if (!body.name) { $('#bd-msg').textContent = 'Device name is required.'; return; }
  try {
    if (bdEditId) await api('/integrations/biometric/devices/' + bdEditId, { method: 'PUT', body: JSON.stringify(body) });
    else await api('/integrations/biometric/devices', { method: 'POST', body: JSON.stringify(body) });
    bdReset();
    $('#bd-msg').textContent = '✓ Saved.';
    loadBioDevices();
  } catch (e) { $('#bd-msg').textContent = '✕ ' + e.message; }
};
$('#biodev-rows').addEventListener('click', async (ev) => {
  const eBtn = ev.target.closest('[data-bd-edit]');
  const dBtn = ev.target.closest('[data-bd-del]');
  if (eBtn) {
    const v = bdDevices.find((x) => x.id === Number(eBtn.dataset.bdEdit));
    if (!v) return;
    bdEditId = v.id;
    $('#bd-name').value = v.name || '';
    $('#bd-serial').value = v.device_serial || '';
    $('#bd-loc').value = v.location || '';
    $('#bd-ip').value = v.ip_address || '';
    $('#bd-method').value = v.integration_method || 'MIDDLEWARE_PUSH';
    $('#bd-vendor').value = v.vendor || '';
    $('#bd-status').value = v.status || 'ACTIVE';
    $('#bd-save').textContent = 'Save changes';
    $('#bd-msg').textContent = 'Editing "' + v.name + '" — change the fields and press Save changes.';
  }
  if (dBtn) {
    if (!window.confirm('Delete this punch device? Its punch history is kept.')) return;
    try {
      await api('/integrations/biometric/devices/' + Number(dBtn.dataset.bdDel), { method: 'DELETE' });
      bdReset();
      loadBioDevices();
    } catch (e) { $('#bd-msg').textContent = '✕ ' + e.message; }
  }
});
async function loadBiometric() {
  const date = $('#bio-date').value || today();
  try {
    const d = await api('/integrations/biometric/logs?per_page=200&date=' + encodeURIComponent(date));
    const pc = { IN: 't-ok', OUT: 't-off', BREAK_IN: 't-warn', BREAK_OUT: 't-warn' };
    $('#bio-rows').innerHTML = (d.data || []).map((l) => '<tr>'
      + '<td>' + dt(l.punched_at) + '</td>'
      + '<td><span class="nm">' + esc(fullName(l.employee) || '—') + '</span>' + (l.employee ? '' : ' <span class="tag t-warn">UNMAPPED</span>') + '</td>'
      + '<td>' + esc(l.biometric_employee_id) + '</td>'
      + '<td><span class="tag ' + (pc[l.punch_type] || 't-off') + '">' + esc(l.punch_type || '—') + '</span></td>'
      + '<td>' + esc(l.verification_mode || '—') + '</td></tr>').join('')
      || '<tr><td colspan="5" class="mut">No punches for ' + esc(date) + '. Push logs from the device middleware or import a CSV below.</td></tr>';
  } catch (e) {
    $('#bio-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="5" class="mut">' + esc(e.message) + '</td></tr>';
  }
  try {
    const m = await api('/reports/biometric-mismatch?date=' + encodeURIComponent(date));
    const badge = (s) => {
      const map = { MISMATCH: 't-danger', OK: 't-ok', NO_BIOMETRIC: 't-warn', NO_SYSTEM_LOGIN: 't-warn', UNKNOWN: 't-off' };
      return '<span class="tag ' + (map[s] || 't-off') + '">' + esc(s) + '</span>';
    };
    $('#bio-mm-rows').innerHTML = (m.data || []).map((r) => '<tr>'
      + '<td><span class="nm">' + esc(r.name || '#' + r.employee_id) + '</span></td>'
      + '<td>' + (r.biometric_in ? dt(r.biometric_in) : '—') + '</td>'
      + '<td>' + (r.system_login ? dt(r.system_login) : '—') + '</td>'
      + '<td>' + (r.diff_minutes ?? '—') + '</td><td>' + badge(r.status) + '</td></tr>').join('')
      || '<tr><td colspan="5" class="mut">Nothing to reconcile for ' + esc(date) + '.</td></tr>';
  } catch (e) {
    $('#bio-mm-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="5" class="mut">' + esc(e.message) + '</td></tr>';
  }
}
$('#bio-load').onclick = loadBiometric;
$('#bio-date').addEventListener('change', loadBiometric);
$('#bio-import').onclick = async () => {
  const f = $('#bio-file').files[0];
  const msg = $('#bio-import-msg');
  if (!f) { msg.textContent = 'Choose a CSV file first.'; return; }
  const fd = new FormData();
  fd.append('file', f);
  try {
    const r = await api('/integrations/biometric/import', { method: 'POST', body: fd });
    msg.textContent = '✓ Imported ' + (r.stored ?? 0) + ' punches.';
    $('#bio-file').value = '';
    loadBiometric();
  } catch (e) { msg.textContent = '✕ ' + e.message; }
};
$('#bio-map-save').onclick = async () => {
  const msg = $('#bio-map-msg');
  const bioId = $('#bio-map-id').value.trim(), empId = $('#bio-map-emp').value;
  if (!bioId || !empId) { msg.textContent = 'Enter the biometric ID and pick an employee.'; return; }
  try {
    await api('/integrations/biometric/map-employee', { method: 'POST', body: JSON.stringify({ biometric_employee_id: bioId, employee_id: Number(empId) }) });
    msg.textContent = '✓ Mapped. Existing unmapped punches for this ID were back-filled.';
    $('#bio-map-id').value = '';
    loadBiometric();
  } catch (e) { msg.textContent = '✕ ' + e.message; }
};

// ---- 9. reports & exports ----
function initReports() {
  const d = today(), m = d.slice(0, 7);
  [['#rp-att-from', d], ['#rp-att-to', d], ['#rp-prod-from', d], ['#rp-prod-to', d],
   ['#rp-comp-from', d], ['#rp-comp-to', d], ['#rp-sum-from', d], ['#rp-sum-to', d],
   ['#rp-reg-month', m], ['#rp-ms-month', m]]
    .forEach(([s, v]) => { if (!$(s).value) $(s).value = v; });
}
$('#rp-att').onclick = () => downloadCsv('/export/attendance?from=' + $('#rp-att-from').value + '&to=' + $('#rp-att-to').value, 'attendance_' + $('#rp-att-from').value + '.csv');
$('#rp-prod').onclick = () => downloadCsv('/export/productivity?from=' + $('#rp-prod-from').value + '&to=' + $('#rp-prod-to').value, 'productivity_' + $('#rp-prod-from').value + '_' + $('#rp-prod-to').value + '.csv');
$('#rp-comp').onclick = () => downloadCsv('/export/compliance?from=' + $('#rp-comp-from').value + '&to=' + $('#rp-comp-to').value, 'compliance_' + $('#rp-comp-from').value + '.csv');
$('#rp-sum').onclick = () => downloadCsv('/export/daily-summary?from=' + $('#rp-sum-from').value + '&to=' + $('#rp-sum-to').value, 'daily_summary_' + $('#rp-sum-from').value + '_' + $('#rp-sum-to').value + '.csv');
$('#rp-reg').onclick = () => {
  const m = $('#rp-reg-month').value || today().slice(0, 7);
  downloadCsv('/export/attendance-register?month=' + encodeURIComponent(m), 'attendance_register_' + m + '.csv');
};
async function loadMonthlySummary() {
  const m = $('#rp-ms-month').value || today().slice(0, 7);
  $('#ms-card').classList.remove('hide');
  $('#ms-title').firstChild.textContent = 'Monthly summary — ' + m + ' ';
  $('#ms-rows').innerHTML = '<tr><td colspan="9" class="mut">Loading…</td></tr>';
  try {
    const d = await api('/reports/monthly-summary?month=' + encodeURIComponent(m));
    $('#ms-rows').innerHTML = (d.data || []).map((r) => '<tr>'
      + '<td>' + esc(r.employee_code || '—') + '</td>'
      + '<td><span class="nm">' + esc(r.name) + '</span></td>'
      + '<td>' + (r.working_days_in_month ?? 0) + '</td>'
      + '<td><span class="tag t-ok">' + (r.present ?? 0) + '</span></td>'
      + '<td><span class="tag t-danger">' + (r.absent ?? 0) + '</span></td>'
      + '<td><span class="tag t-warn">' + (r.half_day ?? 0) + '</span></td>'
      + '<td><span class="tag t-info">' + (r.on_leave ?? 0) + '</span></td>'
      + '<td><b>' + (r.payable_days ?? 0) + '</b></td>'
      + '<td>' + (r.avg_productivity_score == null ? '—' : r.avg_productivity_score) + '</td></tr>').join('')
      || '<tr><td colspan="9" class="mut">No active employees for ' + esc(m) + '.</td></tr>';
  } catch (e) {
    $('#ms-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="9" class="mut">' + esc(e.message) + '</td></tr>';
  }
}
$('#rp-ms').onclick = loadMonthlySummary;
document.querySelectorAll('[data-export]').forEach((b) => b.addEventListener('click', () => {
  const kind = b.dataset.export;
  const qs = kind === 'productivity' ? '?date=' + today() : '?from=' + today() + '&to=' + today();
  downloadCsv('/export/' + kind + qs, kind + '_' + today() + '.csv');
}));

// ---- drawer / drill-down ----
let DID = null;
async function openEmployee(id, name) {
  DID = id;
  $('#d-name').textContent = name; $('#d-sub').textContent = 'Employee #' + id + ' · today';
  $('#drawer').classList.add('open');
  $$('.tab').forEach((tb) => tb.classList.toggle('active', tb.dataset.tab === 'timeline'));
  loadTab('timeline');
}
function closeDrawer() { $('#drawer').classList.remove('open'); }
$('#drawer-x').onclick = closeDrawer;
$$('.tab').forEach((tb) => tb.onclick = () => {
  $$('.tab').forEach((x) => x.classList.remove('active')); tb.classList.add('active'); loadTab(tb.dataset.tab);
});
async function loadTab(tab) {
  const body = $('#d-body'); body.innerHTML = '<div class="mut">Loading…</div>';
  try {
    if (tab === 'timeline') {
      const d = await api('/reports/employee/' + DID + '/timeline');
      body.innerHTML = d.timeline.length ? '<div class="tl">' + d.timeline.map((e) =>
        '<div class="ev"><span class="tm">' + t(e.time) + '</span>' + esc(e.label) + (e.detail ? ' <span class="mut">(' + esc(e.detail) + ')</span>' : '') + '</div>').join('') + '</div>'
        : '<div class="mut">No events today.</div>';
    } else if (tab === 'apps') {
      const d = await api('/reports/employee/' + DID + '/app-usage');
      body.innerHTML = tableFrom(d.data, ['app_name', 'category', 'seconds', 'status'], ['App', 'Category', 'Time', 'Status'], true);
    } else if (tab === 'sites') {
      const d = await api('/reports/employee/' + DID + '/website-usage');
      body.innerHTML = tableFrom(d.data, ['site', 'category', 'seconds', 'status'], ['Site', 'Category', 'Time', 'Status'], true);
    } else if (tab === 'compliance') {
      const d = await api('/reports/employee/' + DID + '/compliance');
      body.innerHTML = tableFrom(d.data, ['started_at', 'event_type', 'severity', 'detected_value'], ['Time', 'Type', 'Severity', 'Detected'], false);
    }
  } catch (e) { body.innerHTML = '<div class="mut">' + (isDenied(e) ? 'Your role cannot view this tab.' : esc(e.message)) + '</div>'; }
}
function tableFrom(rows, keys, heads, secs) {
  if (!rows || !rows.length) return '<div class="mut">No data.</div>';
  return '<table><thead><tr>' + heads.map((h) => '<th>' + esc(h) + '</th>').join('') + '</tr></thead><tbody>'
    + rows.map((r) => '<tr>' + keys.map((k) => {
      let v = r[k];
      if (k === 'seconds' && secs) v = secH(Number(v));
      if (k === 'started_at') v = t(v);
      return '<td>' + esc(String(v ?? '')) + '</td>';
    }).join('') + '</tr>').join('') + '</tbody></table>';
}

// ---- CSV download (with auth header) ----
async function downloadCsv(path, filename) {
  try {
    const blob = await apiBlob(path);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
    $('#rp-msg') && ($('#rp-msg').textContent = '✓ ' + filename + ' downloaded.');
  } catch (e) {
    const m = e.status === 403 ? 'Your role cannot export data (export.data permission required).' : e.message;
    if (CURRENT === 'reports') $('#rp-msg').textContent = '✕ ' + m; else alert(m);
  }
}

// ---- 10. users (login accounts) ----
const ROLES = [
  ['SUPER_ADMIN', 'Super Admin'], ['COMPANY_ADMIN', 'Company Admin'], ['BRANCH_ADMIN', 'Branch Admin'],
  ['HR_ADMIN', 'HR Admin'], ['MANAGER', 'Manager'], ['TEAM_LEADER', 'Team Leader'],
  ['EMPLOYEE', 'Employee'], ['COMPLIANCE_OFFICER', 'Compliance Officer'], ['AUDITOR', 'Auditor'],
];
let USER_LIST = [], USER_EDIT_ID = null, USER_SEARCH_TIMER = null;
async function loadUsers() {
  const q = $('#u-q').value.trim();
  try {
    const d = await api('/users?per_page=200' + (q ? '&q=' + encodeURIComponent(q) : ''));
    USER_LIST = d.data || [];
    $('#u-rows').innerHTML = USER_LIST.map((u) => {
      const roleLabel = (ROLES.find((r) => r[0] === u.role) || [null, u.role_name || u.role || '—'])[1];
      return '<tr data-uid="' + u.id + '">'
        + '<td><span class="nm">' + esc(u.name) + '</span>'
        + (u.must_change_password ? ' <span class="tag t-warn" title="Still on a temporary password">TEMP PW</span>' : '') + '</td>'
        + '<td>' + esc(u.email) + '</td>'
        + '<td><span class="tag t-info">' + esc(roleLabel) + '</span></td>'
        + '<td>' + esc(u.employee ? u.employee.name + ' (' + (u.employee.code || '#' + u.employee.id) + ')' : '—') + '</td>'
        + '<td><span class="tag ' + (u.status === 'ACTIVE' ? 't-ok' : 't-off') + '">' + esc(u.status || '—') + '</span></td>'
        + '<td>' + (u.last_login_at ? dt(u.last_login_at) : '—') + '</td>'
        + '<td class="row" style="flex-wrap:nowrap">'
        + '<button class="btn" data-uact="edit">Edit</button>'
        + '<button class="btn" data-uact="reset">Reset password</button>'
        + (u.status === 'ACTIVE' ? '<button class="btn danger" data-uact="disable">Disable</button>' : '')
        + '</td></tr>';
    }).join('') || '<tr><td colspan="7" class="mut">No users' + (q ? ' matching "' + esc(q) + '"' : ' yet — add the first login account') + '.</td></tr>';
  } catch (e) {
    $('#u-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="7" class="mut">' + esc(e.message) + '</td></tr>';
  }
}
$('#u-q').addEventListener('input', () => { clearTimeout(USER_SEARCH_TIMER); USER_SEARCH_TIMER = setTimeout(loadUsers, 300); });
$('#u-rows').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-uact]');
  if (!btn) return;
  const tr = btn.closest('tr[data-uid]');
  const u = USER_LIST.find((x) => x.id === Number(tr.dataset.uid));
  if (!u) return;
  if (btn.dataset.uact === 'edit') { openUserModal(u); return; }
  if (btn.dataset.uact === 'reset') {
    if (!confirm('Reset the password for ' + u.email + '?\nAll their sessions are signed out and a new one-time password is generated.')) return;
    try {
      const r = await api('/users/' + u.id + '/reset-password', { method: 'POST' });
      showCredentials(u.email, r.temp_password);
      loadUsers();
    } catch (err) { alert(err.message); }
    return;
  }
  if (btn.dataset.uact === 'disable') {
    if (!confirm('Disable ' + u.email + '?\nThey are signed out everywhere immediately and can no longer log in.')) return;
    try { await api('/users/' + u.id, { method: 'DELETE' }); loadUsers(); }
    catch (err) { alert(err.message); }
  }
});
async function openUserModal(u) {
  USER_EDIT_ID = u ? u.id : null;
  $('#u-m-title').textContent = u ? 'Edit user' : 'Add user';
  $('#u-m-err').textContent = '';
  const roleSel = $('#uf-role');
  if (!roleSel.options.length) fillSelect(roleSel, ROLES, (r) => r[1], (r) => r[0]);
  $('#uf-name').value = u ? (u.name || '') : '';
  $('#uf-email').value = u ? (u.email || '') : '';
  roleSel.value = (u && u.role) || 'EMPLOYEE';
  $('#uf-status').value = (u && u.status) || 'ACTIVE';
  $('#uf-status').disabled = !u; // new accounts always start ACTIVE
  const empSel = $('#uf-emp');
  if (u) {
    // The API only accepts the employee link at creation — show it read-only.
    fillSelect(empSel, u.employee ? [u.employee] : [], (r) => r.name + ' (' + (r.code || '#' + r.id) + ')', (r) => r.id, u.employee ? null : '— none —');
    empSel.disabled = true;
  } else {
    empSel.disabled = false;
    try {
      const emps = await employeesList();
      fillSelect(empSel, emps, (e) => fullName(e) + ' (' + (e.employee_code || '#' + e.id) + ')', (e) => e.id, '— none —');
    } catch (e) { fillSelect(empSel, [], (x) => x, (x) => x, '— none —'); }
  }
  $('#user-ovl').classList.add('open');
}
$('#u-add').onclick = () => openUserModal(null);
$('#u-m-save').onclick = async () => {
  $('#u-m-err').textContent = '';
  const body = {
    name: $('#uf-name').value.trim(),
    email: $('#uf-email').value.trim(),
    role: $('#uf-role').value,
  };
  if (!body.name || !body.email) { $('#u-m-err').textContent = 'Name and email are required.'; return; }
  try {
    if (USER_EDIT_ID) {
      body.status = $('#uf-status').value;
      await api('/users/' + USER_EDIT_ID, { method: 'PUT', body: JSON.stringify(body) });
      $('#user-ovl').classList.remove('open');
    } else {
      if ($('#uf-emp').value) body.employee_id = Number($('#uf-emp').value);
      const r = await api('/users', { method: 'POST', body: JSON.stringify(body) });
      $('#user-ovl').classList.remove('open');
      showCredentials(body.email, r.temp_password);
    }
    loadUsers();
  } catch (err) { $('#u-m-err').textContent = err.message; }
};

// ---- one-time credentials panel (user create / reset / employee auto-login) ----
function showCredentials(email, tempPassword) {
  $('#cred-email').value = email || '';
  $('#cred-pass').value = tempPassword || '';
  $('#cred-msg').textContent = '';
  $('#cred-ovl').classList.add('open');
}
$('#cred-copy').onclick = async () => {
  const text = 'Login: ' + $('#cred-email').value + '\nTemporary password: ' + $('#cred-pass').value;
  try {
    await navigator.clipboard.writeText(text);
    $('#cred-msg').textContent = '✓ Copied to clipboard.';
  } catch (e) {
    $('#cred-pass').select();
    $('#cred-msg').textContent = 'Clipboard blocked by the browser — the password is selected, press Ctrl+C.';
  }
};

// ---- 11. attendance sheet + regularization ----
let ATT_LIST = [], ATT_EDIT_ID = null;
function initAttendance() {
  if (!$('#at-date').value) $('#at-date').value = today();
  const ySel = $('#hol-year');
  if (!ySel.options.length) {
    const y = new Date().getFullYear();
    fillSelect(ySel, [y - 1, y, y + 1], (v) => String(v), (v) => String(v));
    ySel.value = String(y);
    ySel.addEventListener('change', loadHolidays);
  }
  loadAttendance();
  loadHolidays();
}
async function loadAttendance() {
  const date = $('#at-date').value || today(), st = $('#at-status').value;
  // Notes accumulate one line per correction — show the latest, full text on hover.
  const lastNote = (s) => { const line = String(s || '').trim().split('\n').pop() || ''; return line.length > 70 ? line.slice(0, 70) + '…' : line; };
  try {
    const d = await api('/attendance?per_page=200&date=' + encodeURIComponent(date) + (st ? '&status=' + encodeURIComponent(st) : ''));
    ATT_LIST = d.data || [];
    const sc = { PRESENT: 't-ok', ABSENT: 't-danger', HALF_DAY: 't-warn', ON_LEAVE: 't-info', MISMATCH: 't-warn' };
    $('#at-rows').innerHTML = ATT_LIST.map((r) => '<tr>'
      + '<td><span class="nm">' + esc(r.employee_name || '#' + r.employee_id) + '</span> <span style="color:var(--ink-3)">' + esc(r.employee_code || '') + '</span></td>'
      + '<td><span class="tag ' + (sc[r.status] || 't-off') + '">' + esc(r.status || '—') + '</span></td>'
      + '<td>' + t(r.check_in_at) + '</td><td>' + t(r.check_out_at) + '</td>'
      + '<td>' + (r.late_minutes ?? 0) + '</td>'
      + '<td>' + esc(r.source || '—') + '</td>'
      + '<td title="' + esc(r.notes || '') + '">' + (esc(lastNote(r.notes)) || '—') + '</td>'
      + '<td><button class="btn" data-att-edit="' + r.id + '">Edit</button></td></tr>').join('')
      || '<tr><td colspan="8" class="mut">No attendance rows for ' + esc(date) + '. Rows appear from agent logins, biometric punches or the nightly marking job — use "+ Add missed day" to record one manually.</td></tr>';
  } catch (e) {
    $('#at-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="8" class="mut">' + esc(e.message) + '</td></tr>';
  }
}
$('#at-load').onclick = loadAttendance;
$('#at-date').addEventListener('change', loadAttendance);
$('#at-status').addEventListener('change', loadAttendance);
$('#at-add').onclick = () => openAttModal(null);
$('#at-rows').addEventListener('click', (e) => {
  const btn = e.target.closest('[data-att-edit]');
  if (!btn) return;
  const r = ATT_LIST.find((x) => x.id === Number(btn.dataset.attEdit));
  if (r) openAttModal(r);
});
// "YYYY-MM-DD HH:MM:SS" ⇄ datetime-local's "YYYY-MM-DDTHH:MM"
const toLocalDt = (s) => s ? String(s).replace(' ', 'T').slice(0, 16) : '';
const fromLocalDt = (v) => v ? v.replace('T', ' ') + ':00' : null;
async function openAttModal(row) {
  ATT_EDIT_ID = row ? row.id : null;
  $('#att-m-title').textContent = row
    ? 'Regularize — ' + (row.employee_name || '#' + row.employee_id) + ' · ' + (row.work_date || '')
    : 'Add missed day';
  $('#att-m-err').textContent = '';
  const empSel = $('#af-emp');
  if (row) {
    fillSelect(empSel, [row], (r) => (r.employee_name || '#' + r.employee_id) + (r.employee_code ? ' (' + r.employee_code + ')' : ''), (r) => r.employee_id);
    empSel.disabled = true;
    $('#af-date').value = row.work_date || '';
    $('#af-date').disabled = true;
    $('#af-status').value = ['PRESENT', 'ABSENT', 'HALF_DAY', 'ON_LEAVE'].includes(row.status) ? row.status : 'PRESENT';
    $('#af-in').value = toLocalDt(row.check_in_at);
    $('#af-out').value = toLocalDt(row.check_out_at);
  } else {
    empSel.disabled = false;
    try { fillEmpPicker(empSel, await employeesList()); }
    catch (e) { fillSelect(empSel, [], (x) => x, (x) => x, isDenied(e) ? 'Your role cannot list employees' : e.message); }
    $('#af-date').disabled = false;
    $('#af-date').value = $('#at-date').value || today();
    $('#af-status').value = 'PRESENT';
    $('#af-in').value = ''; $('#af-out').value = '';
  }
  $('#af-reason').value = '';
  $('#att-ovl').classList.add('open');
}
$('#att-m-save').onclick = async () => {
  $('#att-m-err').textContent = '';
  const reason = $('#af-reason').value.trim();
  if (!reason) { $('#att-m-err').textContent = 'A reason is required — corrections feed payroll and are audited.'; return; }
  const body = {
    status: $('#af-status').value,
    check_in_at: fromLocalDt($('#af-in').value),
    check_out_at: fromLocalDt($('#af-out').value),
    reason,
  };
  try {
    if (ATT_EDIT_ID) {
      await api('/attendance/' + ATT_EDIT_ID, { method: 'PUT', body: JSON.stringify(body) });
    } else {
      if (!$('#af-emp').value) { $('#att-m-err').textContent = 'Pick an employee.'; return; }
      if (!$('#af-date').value) { $('#att-m-err').textContent = 'Pick a date.'; return; }
      body.employee_id = Number($('#af-emp').value);
      body.work_date = $('#af-date').value;
      await api('/attendance', { method: 'POST', body: JSON.stringify(body) });
    }
    $('#att-ovl').classList.remove('open');
    loadAttendance();
  } catch (err) { $('#att-m-err').textContent = err.message; }
};

// ---- holidays ----
async function loadHolidays() {
  const y = $('#hol-year').value;
  try {
    const d = await api('/holidays?year=' + encodeURIComponent(y));
    $('#hol-rows').innerHTML = (d.data || []).map((h) => '<tr>'
      + '<td><b>' + esc(h.holiday_date) + '</b></td>'
      + '<td>' + esc(h.name) + '</td>'
      + '<td><span class="tag ' + (h.type === 'PUBLIC' ? 't-info' : 't-idle') + '">' + esc(h.type || '—') + '</span></td>'
      + '<td style="text-align:right"><button class="btn danger" data-hol-del="' + h.id + '" data-hol-name="' + esc(h.name) + '">✕</button></td></tr>').join('')
      || '<tr><td colspan="4" class="mut">No holidays for ' + esc(y) + ' — add them below so nobody is marked late or absent on those days.</td></tr>';
  } catch (e) {
    $('#hol-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="4" class="mut">' + esc(e.message) + '</td></tr>';
  }
}
$('#hol-add').onclick = async () => {
  const msg = $('#hol-msg');
  msg.textContent = '';
  const body = { holiday_date: $('#hol-date').value, name: $('#hol-name').value.trim(), type: $('#hol-type').value };
  if (!body.holiday_date || !body.name) { msg.textContent = 'Pick a date and enter a name.'; return; }
  try {
    await api('/holidays', { method: 'POST', body: JSON.stringify(body) });
    $('#hol-date').value = ''; $('#hol-name').value = '';
    msg.textContent = '✓ Added.';
    loadHolidays();
  } catch (e) { msg.textContent = '✕ ' + e.message; }
};
$('#hol-rows').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-hol-del]');
  if (!btn) return;
  if (!confirm('Remove holiday "' + btn.dataset.holName + '"?')) return;
  try { await api('/holidays/' + Number(btn.dataset.holDel), { method: 'DELETE' }); loadHolidays(); }
  catch (err) { $('#hol-msg').textContent = '✕ ' + err.message; }
});

// ---- forced password change (must_change_password) ----
function openForcedPwd() {
  ['#pw-cur', '#pw-new', '#pw-conf'].forEach((s) => { $(s).value = ''; });
  $('#pw-err').textContent = '';
  $('#pwd-ovl').classList.add('open'); // no ✕ and no click-outside — change it or sign out
}
$('#pw-save').onclick = async () => {
  $('#pw-err').textContent = '';
  const cur = $('#pw-cur').value, nw = $('#pw-new').value, cf = $('#pw-conf').value;
  if (!cur || !nw) { $('#pw-err').textContent = 'Enter your current and new password.'; return; }
  if (nw !== cf) { $('#pw-err').textContent = 'New password and confirmation do not match.'; return; }
  try {
    await api('/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ current_password: cur, new_password: nw, new_password_confirmation: cf }),
    });
    ME.must_change_password = false;
    $('#pwd-ovl').classList.remove('open');
  } catch (e) { $('#pw-err').textContent = e.message; }
};
$('#pw-signout').onclick = () => { $('#pwd-ovl').classList.remove('open'); $('#signout').click(); };

// ---- licence (R2-1) ----
async function loadLicense() {
  const box = $('#lic-status');
  try {
    const d = await api('/license');
    const pill = (txt, color) => `<span style="display:inline-block;padding:3px 10px;border-radius:999px;font-weight:700;font-size:12px;background:${color}22;color:${color}">${txt}</span>`;
    const STATUS_COLORS = { active: '#16A34A', expired: '#D97706', unconfigured: '#6B7B90' };
    const color = d.operational ? (STATUS_COLORS[d.status] || '#16A34A') : '#DC2626';
    if (!d.configured) {
      const left = d.evaluation_days_left;
      box.innerHTML = left > 0
        ? `${pill('EVALUATION', '#D97706')} <span class="hint">free evaluation — <b>${left} day${left === 1 ? '' : 's'} left</b> (ends ${d.evaluation_ends_at}). After that, monitoring stops until a licence key is entered below.</span>`
        : `${pill('EVALUATION ENDED', '#DC2626')} <span class="hint"><b>Monitoring is blocked.</b> The 7-day evaluation has ended — enter your licence key below to resume instantly. Get a key from the client portal or WhatsApp 90000 98877.</span>`;
      return;
    }
    const rows = [
      ['Status', `${pill(d.status.toUpperCase().replace(/_/g, ' '), color)} ${d.operational ? '' : ' — agent sync is blocked'}${d.status === 'expired' && d.within_grace ? ` (grace period: renew within ${d.grace_days} days of expiry)` : ''}`],
      ['Key', `<code>${d.key_masked || ''}</code>`],
      ['Company', d.company || '—'],
      ['Plan', (d.plan || '—') + (d.kind ? ' · ' + d.kind : '') + (d.deployment ? ' · ' + d.deployment.replace('_', '-') : '')],
      ['Device seats', d.device_limit != null ? `${d.devices_registered} registered / ${d.device_limit} licensed` : `${d.devices_registered} registered`],
      ['Expires', d.expires_at ? `${d.expires_at} (+${d.grace_days} grace days)` : 'never (perpetual)'],
      ['Last check', d.last_checked_at || 'never'],
      ['Central', d.central_url || 'not set (SMARTEPT_LICENSE_URL)'],
    ];
    box.innerHTML = '<table>' + rows.map(([k, v]) => `<tr><th style="text-align:left;white-space:nowrap;padding:6px 18px 6px 0">${k}</th><td>${v}</td></tr>`).join('') + '</table>'
      + (d.last_error ? `<div class="mut" style="color:#DC2626;margin-top:8px">Last error: ${d.last_error}</div>` : '');
  } catch (e) { box.innerHTML = `<span style="color:#DC2626">${e.message}</span>`; }
}
$('#lic-save').onclick = async () => {
  const key = $('#lic-key').value.trim().toUpperCase();
  if (!key) { $('#lic-msg').textContent = 'Enter the licence key first.'; return; }
  $('#lic-msg').textContent = 'Validating with SmartEPT Central…';
  try {
    const d = await api('/license', { method: 'POST', body: JSON.stringify({ key }) });
    $('#lic-msg').textContent = d.status === 'active' ? '✓ Licence activated.' : 'Central answered: ' + (d.last_error || d.status);
    $('#lic-key').value = '';
    loadLicense();
  } catch (e) { $('#lic-msg').textContent = e.message; }
};
$('#lic-check').onclick = async () => {
  $('#lic-msg').textContent = 'Checking…';
  try {
    const d = await api('/license/validate', { method: 'POST' });
    $('#lic-msg').textContent = d.status === 'active' ? '✓ Valid — bundle refreshed.' : 'Central answered: ' + (d.last_error || d.status);
    loadLicense();
  } catch (e) { $('#lic-msg').textContent = e.message; }
};

// ---- audit & ops (R2-4) ----
async function loadOps() {
  loadAudit();
  try {
    const s = await api('/ops/storage-usage');
    $('#ops-storage').innerHTML = (s.data || []).length
      ? '<table>' + s.data.map((r) => '<tr><td>' + esc(r.company) + '</td><td>' + r.files + ' files</td><td><b>' + esc(r.human) + '</b></td></tr>').join('') + '</table>'
      : 'No evidence files stored yet.';
  } catch (e) { $('#ops-storage').textContent = e.message; }
  try {
    const b = await api('/ops/backups');
    $('#ops-backups').innerHTML = (b.data || []).length
      ? '<table>' + b.data.slice(0, 5).map((r) => '<tr><td>' + esc(r.name) + '</td><td>' + esc(r.human) + '</td></tr>').join('') + '</table>'
      : 'No backups yet — the first one runs tonight at 01:30, or click "Back up now".';
  } catch (e) { $('#ops-backups').textContent = e.message; }
}
// ---- storage cleanup (17-Jul) ----
$('#ops-cleanup').onclick = () => {
  const d = new Date(); d.setDate(d.getDate() - 30);
  $('#cl-from').value = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  $('#cl-to').value = today();
  $('#cl-confirm').value = ''; $('#cl-msg').textContent = '';
  $('#cleanup-ovl').classList.add('open');
};
$('#cleanup-x').onclick = $('#cleanup-cancel').onclick = () => $('#cleanup-ovl').classList.remove('open');
$('#cleanup-run').onclick = async () => {
  const msg = $('#cl-msg');
  const targets = [];
  if ($('#cl-shots').checked) targets.push('screenshots');
  if ($('#cl-activity').checked) targets.push('activity');
  if ($('#cl-apps').checked) targets.push('app_usage');
  if ($('#cl-sites').checked) targets.push('website_usage');
  if ($('#cl-presence').checked) targets.push('presence');
  if (!targets.length && !$('#cl-delviol').checked) { msg.textContent = 'Pick at least one thing to delete.'; return; }
  if ($('#cl-confirm').value.trim() !== 'DELETE') { msg.textContent = 'Type DELETE (capital letters) to confirm — this cannot be undone.'; return; }
  if (!$('#cl-from').value || !$('#cl-to').value) { msg.textContent = 'Pick both dates.'; return; }
  msg.textContent = 'Deleting…';
  try {
    const r = await api('/ops/storage-cleanup', { method: 'POST', body: {
      from_date: $('#cl-from').value, to_date: $('#cl-to').value, targets: targets,
      keep_violation_evidence: $('#cl-keepviol').checked,
      delete_violation_records: $('#cl-delviol').checked,
    }});
    const parts = Object.entries(r.result || {}).map(([k, v]) =>
      k + ': ' + (v.rows ?? 0) + ' rows' + (v.human ? ' (' + v.human + ' freed)' : ''));
    msg.textContent = '✓ Done — ' + (parts.join(' · ') || 'nothing matched that range.');
    $('#cl-confirm').value = '';
    loadOps();
  } catch (e) { msg.textContent = e.message; }
};

async function loadAudit() {
  try {
    const p = new URLSearchParams();
    if ($('#au-action').value.trim()) p.set('action', $('#au-action').value.trim());
    if ($('#au-from').value) p.set('from', $('#au-from').value);
    if ($('#au-to').value) p.set('to', $('#au-to').value);
    const d = await api('/audit-logs?' + p.toString());
    $('#au-rows').innerHTML = (d.data || []).map((r) => '<tr>'
      + '<td>' + dt(r.created_at) + '</td>'
      + '<td>' + esc(r.user?.name || '—') + '</td>'
      + '<td><b>' + esc(r.action) + '</b></td>'
      + '<td>' + esc((r.subject_type || '').split('\\').pop() + (r.subject_id ? ' #' + r.subject_id : '')) + '</td>'
      + '<td class="mut" style="max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(r.changes ? JSON.stringify(r.changes) : '') + '</td>'
      + '<td>' + esc(r.ip || '') + '</td></tr>').join('')
      || '<tr><td colspan="6" class="mut">No audit entries match.</td></tr>';
  } catch (e) {
    $('#au-rows').innerHTML = isDenied(e) ? deniedCard() : '<tr><td colspan="6" class="mut">' + esc(e.message) + '</td></tr>';
  }
}
$('#au-go').onclick = loadAudit;
$('#ops-backup-now').onclick = async () => {
  $('#ops-backup-msg').textContent = 'Backing up…';
  try {
    const r = await api('/ops/backup', { method: 'POST' });
    $('#ops-backup-msg').textContent = '✓ ' + (r.output || 'Done.');
    loadOps();
  } catch (e) { $('#ops-backup-msg').textContent = e.message; }
};

// ---- ⓘ help ----
const HELP = {
  dashboard: ['Live Dashboard', '<h5>What</h5>A real-time picture of the whole company: who is active, idle, on break or offline, plus today\'s violation and screenshot counts and the health of every agent below.<h5>Why</h5>One glance tells you whether the floor is working and whether the monitoring agents themselves are alive and syncing.<h5>How</h5>The table refreshes every 15 seconds automatically. Click any employee row to open their full day — timeline, apps, websites and compliance — in the side drawer.'],
  attendance: ['Attendance', '<h5>What</h5>The day\'s attendance sheet — status per employee (Present, Absent, Half-day, On leave) with check-in/out, late minutes and the source of each verdict — plus the company holiday calendar.<h5>Why</h5>This sheet feeds payroll, so it must be complete and correctable: a downed biometric reader or a forgotten leave application should not cost anyone a day\'s pay.<h5>How</h5>Pick a date and optionally a status filter. Edit any row to regularize it, or use "+ Add missed day" for a date with no record — both require a written reason that is stored on the record and audit-logged, and the row\'s source becomes MANUAL. Maintain holidays below: no late/absent marking happens on them and they appear as HD in the monthly register.'],
  screenshots: ['Screenshots', '<h5>What</h5>The screen captures the desktop agent uploaded for one employee on one day, with the app in focus and the reason each capture fired (interval, random or violation).<h5>Why</h5>Screenshots are the evidence layer: they turn a "13 minutes on YouTube" number into something you can verify before acting.<h5>How</h5>Pick an employee and a date, then click a tile for the full-size image. Captures only exist where the assigned screenshot policy enables them, and every image you open here is recorded in the audit log.'],
  usage: ['Usage & Compliance', '<h5>What</h5>Per-employee time by application and by website for a chosen day, alongside that day\'s compliance events.<h5>Why</h5>This is where productive vs unproductive time becomes concrete — which tools the employee actually used and where policy lines were crossed.<h5>How</h5>Pick an employee and date; categories (PRODUCTIVE, NEUTRAL, blocked) come from the application and website policies you define under Policies. Website names are read from the browser window title in this release.'],
  violations: ['Violations', '<h5>What</h5>The company-wide feed of compliance events: blocked apps and sites, category and severity, what the agent did about it, and a link to screenshot evidence when one was captured.<h5>Why</h5>Reviewing this daily keeps enforcement fair and consistent — the same event always produces the same recorded action.<h5>How</h5>Use "View evidence" to jump straight to that employee\'s screenshots for the day of the event. Export the full log as CSV for HR or audit.'],
  employees: ['Employees', '<h5>What</h5>The employee directory: code, contact, org placement (branch / department / team / shift), employment status and how many monitored devices each person has.<h5>Why</h5>Everything else in SmartEPT hangs off this record — policies resolve through the employee\'s team and department, and agents bind devices to it.<h5>How</h5>Search by name or code, add or edit with the form, and delete with confirmation. Create branches, teams and shifts first so the pickers here have options. When someone leaves, use <b>Relieve</b> (not Delete): one click disables their login, revokes every token, stops the agent on all their PCs and frees the licence seats — with the reason kept in the audit log. Their history stays for reports and payroll.'],
  users: ['Users', '<h5>What</h5>The login accounts for this console and the employee self-service — name, email, role, optional link to an employee record, status and last login.<h5>Why</h5>Accounts and employee records are different things: an auditor logs in but is not an employee, and an employee may exist without any login. Roles decide exactly what each account can see and do.<h5>How</h5>Add a user and SmartEPT generates a strong temporary password shown <b>exactly once</b> — copy it and hand it over; the user must change it at first sign-in. Reset password re-issues a one-time password and signs the user out everywhere. Disable blocks login immediately and kills active sessions; accounts are never hard-deleted because the audit trail references them.'],
  devices: ['Devices', '<h5>What</h5>Every PC where the SmartEPT agent is registered: hostname, OS, agent version, live status, compliance state, sync backlog and last heartbeat.<h5>Why</h5>A stopped or stale agent means a blind spot — this screen tells you whether the data you see elsewhere is complete.<h5>How</h5>Healthy agents heartbeat about every 30 seconds. A growing sync queue with an OFFLINE status usually just means the PC is off; DEGRADED or STOPPED health on an online device needs IT attention. <b>Unbind</b> a lost, replaced or misused PC to stop its agent instantly and free its licence seat — it stays blocked until you <b>Approve re-bind</b>, so nobody can quietly reconnect it.'],
  policies: ['Policies', '<h5>What</h5>The control room: 12 policy types (monitoring master switch, screenshots, webcam presence, app/site rules, network, USB, breaks, attendance, compliance scoring) with versioned edit forms and an assignment panel.<h5>Why</h5>Nothing is captured because the software can — everything is captured because a policy you wrote says so, and the version trail shows what applied when.<h5>How</h5>Pick a type, create or edit a policy (each save bumps the version; agents pick it up on the next heartbeat), then assign it to the company, a branch, department, team, employee or single device. More specific assignments win.'],
  biometric: ['Biometric', '<h5>What</h5>Door-punch integration: the registered punch devices (readers at gates/doors), the punch log, CSV import, biometric-ID-to-employee mapping, and a daily reconciliation of first punch vs first agent login.<h5>Why</h5>The gap between "in the office" and "at the system" is invisible to either source alone — the mismatch report exposes it in minutes per employee.<h5>How</h5>Push punches from your device middleware or import the device\'s CSV export, map each biometric ID to an employee once (old punches back-fill automatically), then read the mismatch report: OK, MISMATCH over 15 minutes, or NO_BIOMETRIC.'],
  license: ['Licence', '<h5>What</h5>This server\'s SmartEPT licence: the key, the plan and company it belongs to, how many device seats are licensed vs registered, the expiry date with its grace window, and when the server last confirmed all of this with SmartEPT Central. A server with no key runs a <b>7-day free evaluation</b>, then monitoring stops until a key is entered.<h5>Why</h5>The licence is what ties your installation to what you purchased — seats, plan features and validity. Only licence metadata travels to Central: screenshots, activity and camera data never leave this server. If a paid renewal is missed, agents keep working through the grace days so a busy week never stops monitoring mid-shift; trials stop the moment they end.<h5>How</h5>Paste the key from your order email or the client portal and click "Save & validate" — the server confirms it with Central instantly and then re-checks once a day on its own. "Validate now" forces a fresh check after a renewal or seat upgrade. If the status shows EXPIRED, renew from the client portal; the seats line tells you when you\'re close to the licensed device limit.'],
  ops: ['Audit & Ops', '<h5>What</h5>Three operational views in one place: the full audit trail (every admin action, export, screenshot view and licence event with who, when and from which IP), storage consumed by screenshot/webcam evidence per company, and the state of your database backups.<h5>Why</h5>Monitoring software must itself be accountable — when an employee questions an action, the audit trail shows exactly who did what. Storage growth and backups are the two quiet things that sink servers: full disks and "we never had a backup".<h5>How</h5>Filter the trail by action text or date range. Backups run automatically every night at 01:30 (newest 14 kept in storage/app/backups — copy them off this PC for real safety); "Back up now" runs one immediately before risky changes. If a company\'s evidence storage grows fast, tighten its screenshot policy, shorten retention, or use \'Free up storage\' to bulk-delete old screenshots and logs by date range — violation evidence is kept unless you explicitly say otherwise, and every cleanup is itself audit-logged.'],
  reports: ['Reports & Exports', '<h5>What</h5>CSV exports — attendance, productivity, compliance, daily-summary scores and the classic monthly attendance register — plus an on-screen monthly summary with payable days.<h5>Why</h5>These are the hand-off artifacts: payroll wants the register and payable days, managers want productivity, HR wants compliance, and the MD wants the one-page summary.<h5>How</h5>Set the date range (or month for the register and summary), click Export, and the file downloads ready to open in Excel. The monthly summary renders here on screen: working days, P/A/H/L counts, payable days (P + 0.5×H + L) and average productivity. Every export is recorded in the audit log with who ran it and for which dates.'],
};
$('#btn-help').onclick = () => {
  const h = HELP[CURRENT] || HELP.dashboard;
  $('#help-title').textContent = h[0];
  $('#help-body').innerHTML = h[1];
  $('#help-ovl').classList.add('open');
};
// Generic overlay close buttons + click-outside.
$$('[data-close]').forEach((b) => b.addEventListener('click', () => $('#' + b.dataset.close).classList.remove('open')));
// pwd-ovl (forced change) and cred-ovl (one-time password) deliberately have no
// click-outside close — one is mandatory, the other must not vanish on a stray click.
['help-ovl', 'emp-ovl', 'user-ovl', 'att-ovl'].forEach((id) => {
  const el = document.getElementById(id);
  el.addEventListener('click', (e) => { if (e.target === el) el.classList.remove('open'); });
});
</script>
@endverbatim
</body>
</html>
